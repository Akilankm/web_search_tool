# Product Evidence Harness

This repo is a **bounded search-scrape harness** for toy/product URL discovery and product evidence extraction.

It is intentionally **not** an AzureML component yet. It is a local Python package that can be run from scripts or notebooks.

## Required input rules

Each product task requires:

| Field | Required | Rule |
|---|---:|---|
| `main_text` | Yes | Primary product text / product name from input data. |
| `country_code` | Yes | ISO-like country code such as `CZ`, `CH`, `US`. This is the only controlled country parameter. |
| `ean` / `gtin` | No | Strongest identity signal when provided. Matching EAN can verify identity; conflicting EAN blocks selection by default. |
| `retailer_name` | No | Optional dynamic text signal. The code does not maintain retailer lists per country. |
| `language_code` | No | Optional override. If not supplied, language is inferred from `country_profiles.json`. |

## Core decision policy

```text
1. Search requested-country domains/language terms first.
2. Scrape country-specific candidates before global candidates.
3. Use EAN/GTIN as the strongest identity signal.
4. Use global fallback only when country-scoped search does not resolve a usable URL.
5. Use AI Mode for URL discovery/validation/repair, not as final authority.
6. Final URL must be reachable, successfully scraped, scrapable, product-page usable, and matched to the same product.
7. If no candidate passes the final gates, return UNRESOLVED with product_url=None.
8. UNRESOLVED does not mean the product is unavailable online; it means this harness did not resolve a usable URL within budget.
```

## Country profiles

Country behavior is configured here:

```text
src/product_evidence_harness/configs/country_profiles.json
```

The profile contains only:

```text
country code
languages
default language
country TLDs
language profiles with priority/distribution weights
language-local country terms
language-local commerce/search terms
```

It deliberately does **not** contain retailer names/domains. Retailers are dynamic and are discovered from search results.

Example: `CH` is configured with:

```text
languages by internal search priority:
  de German  -> priority 1, distribution_weight 0.62
  fr French  -> priority 2, distribution_weight 0.23
  it Italian -> priority 3, distribution_weight 0.08
  rm Romansh -> priority 4, distribution_weight 0.01
  en English -> priority 5, distribution_weight 0.06
tlds: .ch, .swiss
localized commerce terms: kaufen, acheter, comprare, cumprar, buy
```

You can edit this JSON directly or point to another file:

```python
config = HarnessConfig(
    country_profile_path="./configs/my_country_profiles.json",
)
```

or via environment variable:

```bash
export PRODUCT_HARNESS_COUNTRY_PROFILES=/path/to/country_profiles.json
```

## Per-row output folder

By default, the harness writes compact analytics-friendly CSV outputs under:

```text
output/<row_id>/
├── best_url.csv       # one-row final decision
├── summary.csv        # one-row run summary
├── candidates.csv     # ranked candidate URLs + score/scrape/identity columns
├── scrapes.csv        # compact scrape outcomes
├── actions.csv        # action trace: search/scrape/AI/finish
└── queries.csv        # issued queries/prompts
```

These CSVs are meant for debugging and analytics. They avoid large markdown/page dumps by default.

## Final URL guarantee

The final `product_url` is not allowed to be AI-only, organic-only, unreachable, blocked, soft-404, listing/search/home page, or non-scrapable. Those URLs can still appear in `output/<row_id>/candidates.csv`, but the final result returns a URL only after the scrape and identity gates pass.

If every candidate fails the final gate, the result is:

```text
validation_status = UNRESOLVED
resolution_status = UNRESOLVED
product_url = None
availability_inference = UNKNOWN
```

That is an operational resolution failure, not a product availability claim.

## Core flow

```text
ProductQuery
  ↓
ProductSearchState
  ↓
BoundedHarnessLoop
  ├─ country-language organic_search in configured priority order
  ├─ scrape country candidate
  ├─ next country-language search if not resolved
  ├─ global fallback search only if country search cannot resolve
  ├─ AI Mode URL discovery/validation/repair
  └─ finish
  ↓
CandidateScorecard ranking
  ↓
FinalSelector scrapable/same-product gate
  ↓
ProductURLMatch + output/<row_id>/ CSV folder
```

## Main package

```text
src/product_evidence_harness/
├── contracts.py          # ProductQuery, state, candidates, evidence, scorecards
├── country_profiles.py   # country/language/TLD profile registry; no retailer lists
├── configs/
│   └── country_profiles.json
├── config.py             # SerpAPIConfig, HarnessConfig, HarnessPolicy, budget config
├── planner.py            # bounded next-action policy
├── executor.py           # executes search / AI / scrape actions
├── loop.py               # bounded loop
├── candidate_store.py    # candidate dedupe/merge from organic + AI Mode
├── query_builder.py      # EAN-first, multilingual, country-aware queries
├── scraper.py            # crawl4ai first, requests fallback
├── identity_verifier.py  # deterministic EAN/title/pack-size/page-type checks
├── ranker.py             # transparent scorecards + confidence caps
├── selector.py           # final URL selection gate
├── artifacts.py          # compact per-row CSV writer
└── pipeline.py           # ProductEvidenceHarness entrypoint
```

## Minimal usage

```python
from product_evidence_harness import ProductEvidenceHarness, ProductQuery, SerpAPIConfig, HarnessConfig

harness = ProductEvidenceHarness(
    serp_config=SerpAPIConfig.from_env(country_code="CH", language_code="de"),
    config=HarnessConfig(output_dir="./output"),
)

trace = harness.run(
    ProductQuery(
        row_id="demo-001",
        main_text="LEGO City Feuerwehrstation",
        country_code="CH",
        ean="5702011234567",
        retailer_name=None,
    ),
    return_trace=True,
)

print(trace.best_match.to_dict())
print("Inspect:", "output/demo-001/")
```

## Accuracy-first LLM adjudication

The harness can use Azure OpenAI as a scrape-grounded exact-product judge after candidate URLs are found and scraped with crawl4ai.

Runtime constraints implemented:

- Maximum 4 LLM calls per product by default.
- One candidate URL per call.
- At most one image per call.
- Text-only calls are used first when enough evidence exists.
- If a gateway rejects a payload, the adjudicator retries with a smaller payload.
- Final URL can be configured to require LLM `EXACT_MATCH` / `EXACT_MATCH_WITH_WARNING`.
- Every candidate row keeps deterministic justification; LLM-judged rows additionally include LLM decision, confidence, reject reason, and explanation.

Enable from `.env` using:

```bash
PRODUCT_HARNESS_ENABLE_LLM_ADJUDICATION=true
PRODUCT_HARNESS_REQUIRE_LLM_EXACT_MATCH=true
PRODUCT_HARNESS_LLM_MAX_CALLS_PER_PRODUCT=4
PRODUCT_HARNESS_LLM_ADJUDICATE_TOP_K=3
PRODUCT_HARNESS_LLM_USE_IMAGES=true
PRODUCT_HARNESS_LLM_PAYLOAD_REDUCTION=true
```

Azure OpenAI variables:

```bash
AZURE_OPENAI_API_KEY=...
AZURE_OPENAI_API_VERSION=...
AZURE_OPENAI_ENDPOINT=...
AZURE_OPENAI_DEPLOYMENT=...
LLM_CONSUMER_ID=...   # optional org gateway header
```

Use `HarnessConfig.from_env()` in notebooks/scripts to pick up these settings:

```python
from product_evidence_harness import HarnessConfig

config = HarnessConfig.from_env(".env")
```

Per-row output adds:

```text
output/<row_id>/llm_judgements.csv
output/<row_id>/llm_calls.csv
```
