from __future__ import annotations

import json
from typing import Any

from product_evidence_harness.contracts import CandidateScorecard, ProductQuery

SYSTEM_PROMPT_EXACT_PRODUCT_JUDGE = """You are an exact product URL validation judge.

Decide whether a scraped candidate URL represents the exact same product requested by MAIN_TEXT.
MAIN_TEXT is the primary product identity driver. EAN/GTIN is a strong anchor but retailer pages can omit or occasionally misstate it. Do not accept sibling variants, bundles, displays, packs, different colors, different sizes, different quantities, different language editions, or different formats as exact matches.

Use only the provided scraped evidence and the single image if supplied. Do not browse. Do not invent facts. If evidence is insufficient, return INSUFFICIENT_EVIDENCE.
Return strict JSON only. No markdown.
"""

ALLOWED_DECISIONS = {
    "EXACT_MATCH", "EXACT_MATCH_WITH_WARNING", "SIBLING_VARIANT", "WRONG_PRODUCT",
    "INSUFFICIENT_EVIDENCE", "NON_PRODUCT_PAGE", "UNSCRAPABLE",
}


def build_adjudication_prompt(*, product: ProductQuery, card: CandidateScorecard, payload_level: str, image_url: str | None) -> str:
    c = card.candidate
    s = card.scrape
    v = card.verification
    assert s is not None

    if payload_level == "minimal_text_only":
        evidence: dict[str, Any] = {
            "input": _input(product),
            "candidate": {"url": c.url, "domain": c.domain},
            "scrape": {
                "title": s.title,
                "h1": s.h1,
                "page_product_name": s.page_product_name,
                "gtins": list(s.structured_eans),
                "brand": s.brand,
                "manufacturer": s.manufacturer,
            },
            "deterministic_verification": _verification(v),
        }
    elif payload_level == "compact_text_only" or payload_level == "compact_text_with_image":
        evidence = {
            "input": _input(product),
            "candidate": _candidate(c, card),
            "scrape_status": _scrape_status(s),
            "scraped_product_evidence": {
                "title": s.title,
                "h1": s.h1,
                "page_product_name": s.page_product_name,
                "description": _clip(s.description, 500),
                "gtins": list(s.structured_eans),
                "brand": s.brand,
                "manufacturer": s.manufacturer,
                "availability": s.availability,
                "specs": _limit_dict(s.specs, 12),
                "image_url_used": image_url,
            },
            "deterministic_verification": _verification(v),
        }
    else:
        evidence = {
            "input": _input(product),
            "candidate": _candidate(c, card),
            "scrape_status": _scrape_status(s),
            "scraped_product_evidence": {
                "title": s.title,
                "h1": s.h1,
                "page_product_name": s.page_product_name,
                "description": _clip(s.description, 900),
                "gtins": list(s.structured_eans),
                "brand": s.brand,
                "manufacturer": s.manufacturer,
                "price": s.price,
                "currency": s.currency,
                "availability": s.availability,
                "specs": _limit_dict(s.specs, 20),
                "image_url_used": image_url,
                "markdown_excerpt": _clip(s.markdown_excerpt, 1200),
            },
            "deterministic_verification": _verification(v),
        }

    schema = {
        "exact_product_match": "boolean",
        "decision": sorted(ALLOWED_DECISIONS),
        "confidence": "number 0..1",
        "primary_identity_driver": "short string",
        "main_text_assessment": {"status": "MATCHED|PARTIAL|MISMATCH|UNKNOWN", "reason": "short string"},
        "ean_assessment": {"status": "MATCHED|CONFLICT|ABSENT|NOT_PROVIDED|UNKNOWN", "reason": "short string"},
        "variant_assessment": {"status": "MATCHED|CONFLICT|UNKNOWN", "conflict_terms": ["strings"], "reason": "short string"},
        "scrape_assessment": {"is_product_page": "boolean", "is_scrapable": "boolean", "usable_for_final": "boolean"},
        "image_assessment": {"used": "boolean", "status": "SUPPORTS_MATCH|CONTRADICTS_MATCH|NOT_USED|NOT_USEFUL", "reason": "short string"},
        "reject_reason": "null or short string",
        "final_explanation": "short factual explanation",
    }
    return (
        "INPUT AND SCRAPED CANDIDATE EVIDENCE\n"
        + json.dumps(evidence, ensure_ascii=False, indent=2, default=str)
        + "\n\nTASK\nDecide whether this candidate URL is the exact same product as MAIN_TEXT. "
        "Pay special attention to exact product name, product form, color, size/format, quantity/pack size, edition/language, EAN/GTIN, and whether the page is a valid product detail page.\n\n"
        "Return strict JSON with this shape:\n"
        + json.dumps(schema, ensure_ascii=False, indent=2)
    )


def _input(product: ProductQuery) -> dict[str, Any]:
    return {
        "main_text": product.main_text,
        "ean": product.ean,
        "country_code": product.country_code,
        "retailer_name": product.retailer_name,
        "language_code": product.language_code,
    }


def _candidate(c, card: CandidateScorecard) -> dict[str, Any]:
    return {
        "url": c.url,
        "domain": c.domain,
        "title": c.title,
        "snippet": _clip(c.snippet, 350),
        "source_types": list(c.source_types),
        "country_check": card.country_check,
        "retailer_check": card.retailer_check,
        "deterministic_confidence": card.final_confidence,
    }


def _scrape_status(s) -> dict[str, Any]:
    return {
        "reachable": s.reachable,
        "scraped": s.scraped,
        "success": s.success,
        "is_scrapable": s.is_scrapable,
        "looks_like_product_page": s.looks_like_product_page,
        "status_code": s.status_code,
        "word_count": s.word_count,
        "image_count": s.image_count,
    }


def _verification(v) -> dict[str, Any]:
    if not v:
        return {}
    return {
        "identity_status": v.identity_status,
        "exact_product_check": v.exact_product_check,
        "variant_check": v.variant_check,
        "variant_conflict_terms": list(v.variant_conflict_terms),
        "ean_check": v.ean_check,
        "ean_status": v.ean_status,
        "page_gtins_valid": list(v.page_gtins_valid),
        "title_check": v.title_check,
        "title_match_score": v.title_match_score,
        "quantity_check": v.quantity_check,
        "page_type_check": v.page_type_check,
        "blocking_reasons": list(v.blocking_reasons),
        "justifications": list(v.justifications),
    }


def _clip(text: str | None, n: int) -> str:
    text = text or ""
    return text if len(text) <= n else text[:n] + "..."


def _limit_dict(d: dict[str, Any], n: int) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for idx, (k, v) in enumerate((d or {}).items()):
        if idx >= n:
            break
        out[str(k)[:80]] = _clip(str(v), 300)
    return out
