from __future__ import annotations

from dataclasses import dataclass

from product_evidence_harness.config import HarnessPolicy
from product_evidence_harness.constants import (
    COUNTRY_ALTERNATIVE,
    COUNTRY_MATCHED,
    COUNTRY_NOT_PROVIDED,
    IDENTITY_UNVERIFIED,
    IDENTITY_VERIFIED,
    RETAILER_NOT_PROVIDED,
    VALIDATION_NEEDS_REVIEW,
    VALIDATION_REJECTED,
    VALIDATION_UNRESOLVED,
    VALIDATION_VERIFIED,
)
from product_evidence_harness.contracts import CandidateScorecard, ProductQuery, ProductURLMatch


@dataclass(frozen=True)
class FinalSelector:
    policy: HarnessPolicy = HarnessPolicy()

    def select(self, *, task: ProductQuery, scorecards: list[CandidateScorecard], termination_reason: str | None, budget_snapshot, llm_calls_used: int = 0) -> ProductURLMatch:
        selected = self._select_card(scorecards)
        if not selected:
            return ProductURLMatch(
                row_id=task.row_id,
                main_text=task.main_text,
                country_code=task.country_code,
                retailer_name=task.retailer_name,
                ean=task.ean,
                product_url=None,
                confidence=0.0,
                validation_status=VALIDATION_UNRESOLVED,
                identity_status=IDENTITY_UNVERIFIED,
                is_exact_product_match=False,
                match_reason="No valid scrapable same-product URL was resolved",
                justification=(
                    "The harness did not resolve a final URL that passed all final gates: "
                    "reachable + successfully scraped + scrapable + product-page usable + same-product identity. "
                    "This does not imply the product is unavailable online. Check output/<row_id>/candidates.csv "
                    "and scrapes.csv for the failure reason."
                ),
                termination_reason=termination_reason,
                organic_calls_used=budget_snapshot.organic_used,
                ai_mode_calls_used=budget_snapshot.ai_mode_used,
                scrape_calls_used=budget_snapshot.scrape_used,
                resolution_status="UNRESOLVED",
                availability_inference="UNKNOWN",
                exact_product_check="UNKNOWN",
                variant_check="UNKNOWN",
                identity_driver="NO_FINAL_CANDIDATE",
                primary_reject_reason="NO_VALID_SCRAPABLE_EXACT_PRODUCT_URL",
                llm_calls_used=llm_calls_used,
            )

        scrape = selected.scrape
        verification = selected.verification
        final_status = selected.validation_status
        if final_status == VALIDATION_REJECTED:
            final_status = VALIDATION_NEEDS_REVIEW

        reasons = list(selected.ranking_reasons)
        if selected.llm_used:
            reasons.append(f"llm_decision={selected.llm_decision}")
            if selected.llm_justification:
                reasons.append("llm_justification=" + selected.llm_justification[:500])
        if selected.hard_failures:
            reasons.append("hard_failures=" + "; ".join(selected.hard_failures))
        if selected.soft_warnings:
            reasons.append("warnings=" + "; ".join(selected.soft_warnings))
        justification = " | ".join(reasons) or selected.candidate.evidence_text()[:500]

        return ProductURLMatch(
            row_id=task.row_id,
            main_text=task.main_text,
            country_code=task.country_code,
            retailer_name=task.retailer_name,
            ean=task.ean,
            product_url=selected.candidate.url,
            confidence=selected.final_confidence,
            validation_status=final_status,
            identity_status=verification.identity_status if verification else IDENTITY_UNVERIFIED,
            is_exact_product_match=bool(verification and verification.exact_product_check == "EXACT_MATCH"),
            match_reason="; ".join(selected.ranking_reasons[:5]),
            justification=justification,
            ean_check=verification.ean_check if verification else "UNKNOWN",
            title_check=verification.title_check if verification else "UNKNOWN",
            quantity_check=verification.quantity_check if verification else "UNKNOWN",
            page_type_check=verification.page_type_check if verification else "UNKNOWN",
            retailer_check=selected.retailer_check,
            country_check=selected.country_check,
            requested_quantity=verification.requested_quantity if verification else None,
            page_quantity=verification.page_quantity if verification else None,
            blocking_reasons="; ".join(verification.blocking_reasons if verification else selected.hard_failures),
            hard_failures=selected.hard_failures,
            soft_warnings=selected.soft_warnings,
            termination_reason=termination_reason,
            organic_calls_used=budget_snapshot.organic_used,
            ai_mode_calls_used=budget_snapshot.ai_mode_used,
            scrape_calls_used=budget_snapshot.scrape_used,
            is_scrapable=bool(scrape and scrape.is_scrapable),
            scrape_status_code=scrape.status_code if scrape else None,
            scrape_word_count=scrape.word_count if scrape else 0,
            scrape_markdown_chars=scrape.markdown_chars if scrape else 0,
            scrape_final_url=scrape.final_url if scrape else None,
            richness_score=scrape.richness_score if scrape else 0.0,
            price=scrape.price if scrape else None,
            currency=scrape.currency if scrape else "",
            brand=scrape.brand if scrape else "",
            manufacturer=scrape.manufacturer if scrape else "",
            description=scrape.description if scrape else "",
            specs_count=len(scrape.specs) if scrape else 0,
            image_count=scrape.image_count if scrape else 0,
            specs=dict(scrape.specs) if scrape else {},
            image_urls=tuple(scrape.image_urls) if scrape else (),
            resolution_status="RESOLVED",
            availability_inference="UNKNOWN",
            exact_product_check=verification.exact_product_check if verification else "UNKNOWN",
            variant_check=verification.variant_check if verification else "UNKNOWN",
            variant_conflict_terms=verification.variant_conflict_terms if verification else (),
            identity_driver=verification.identity_driver if verification else "UNKNOWN",
            ean_status=verification.ean_status if verification else "UNKNOWN",
            ean_conflict_is_blocking=verification.ean_conflict_is_blocking if verification else False,
            input_ean_valid=verification.input_ean_valid if verification else None,
            input_ean_normalized=verification.input_ean_normalized if verification else None,
            page_gtins_valid=verification.page_gtins_valid if verification else (),
            page_gtins_ignored=verification.page_gtins_ignored if verification else (),
            selected_with_warning=selected.selected_with_warning,
            primary_reject_reason=selected.primary_reject_reason,
            llm_used=selected.llm_used,
            llm_decision=selected.llm_decision,
            llm_confidence=selected.llm_confidence,
            llm_exact_product_match=selected.llm_exact_product_match,
            llm_reject_reason=selected.llm_reject_reason,
            llm_justification=selected.llm_justification,
            llm_calls_used=llm_calls_used,
        )

    def _is_final_usable(self, card: CandidateScorecard) -> bool:
        """Final URL gate.

        A final URL must be usable for downstream toy-product scraping/coding.
        Search-only or AI-only candidates remain in CSV outputs, but they cannot
        become product_url unless the scrape and identity gates pass.
        """
        scrape = card.scrape
        verification = card.verification
        if not scrape or not verification:
            return False
        if not (scrape.scraped and scrape.success and scrape.reachable and scrape.is_scrapable):
            return False
        if not scrape.looks_like_product_page:
            return False
        if card.hard_failures:
            return False
        if verification.identity_status != IDENTITY_VERIFIED:
            return False
        if verification.exact_product_check not in {"EXACT_MATCH", "UNKNOWN"}:
            return False
        if verification.variant_check == "CONFLICT":
            return False
        if self.policy.require_llm_exact_match_for_final:
            if not card.llm_used:
                return False
            if card.llm_decision not in {"EXACT_MATCH", "EXACT_MATCH_WITH_WARNING"}:
                return False
            if not card.llm_exact_product_match:
                return False
        return True

    def _select_card(self, scorecards: list[CandidateScorecard]) -> CandidateScorecard | None:
        if not scorecards:
            return None

        country_cards = [
            card for card in scorecards
            if card.country_check in {COUNTRY_MATCHED, COUNTRY_NOT_PROVIDED}
        ]
        global_cards = [card for card in scorecards if card.country_check == COUNTRY_ALTERNATIVE]

        for card in country_cards:
            if card.validation_status == VALIDATION_VERIFIED and self._is_final_usable(card):
                return card

        if self.policy.require_country_specific_before_global:
            for card in country_cards:
                if (
                    card.validation_status in {VALIDATION_VERIFIED, VALIDATION_NEEDS_REVIEW}
                    and self._is_final_usable(card)
                    and card.final_confidence >= self.policy.min_review_confidence
                ):
                    return card

        if self.policy.allow_global_fallback:
            for card in global_cards:
                if (
                    card.validation_status in {VALIDATION_VERIFIED, VALIDATION_NEEDS_REVIEW}
                    and self._is_final_usable(card)
                    and card.final_confidence >= self.policy.min_review_confidence
                ):
                    return card

        for card in scorecards:
            if self._is_final_usable(card) and card.final_confidence >= self.policy.min_review_confidence:
                return card

        return None
