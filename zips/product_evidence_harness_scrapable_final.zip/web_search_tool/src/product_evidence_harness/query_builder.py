from __future__ import annotations

import re
from dataclasses import dataclass, field

from product_evidence_harness.contracts import ProductQuery, ProductSearchState, URLCandidate
from product_evidence_harness.country_profiles import CountryProfileRegistry


@dataclass(frozen=True)
class QueryBuilder:
    """Builds bounded, auditable search queries.

    Country search is intentionally first-class. The builder supports countries
    with multiple official/local languages through country_profiles.json. EAN is
    treated as the strongest query token when provided.
    """

    max_query_chars: int = 520
    country_profiles: CountryProfileRegistry = field(default_factory=CountryProfileRegistry.load)

    def primary(self, task: ProductQuery, *, global_fallback: bool = False) -> str:
        profile = self.country_profiles.get(task.country_code)
        lang = task.language_code or profile.default_language
        parts: list[str] = []

        # EAN/GTIN is the highest-precision signal. Keep it near the start.
        if task.ean:
            parts.append(task.ean)
        parts.append(self._quote(task.main_text))
        if task.retailer_name:
            parts.append(task.retailer_name)

        if not global_fallback:
            parts.extend(self._country_filter_terms(task))
        else:
            parts.append("global")

        parts.extend(self._localized_buy_terms(task, lang, max_terms=3))
        return self._truncate(" ".join(parts))

    def secondary(self, task: ProductQuery, *, global_fallback: bool = False) -> str:
        profile = self.country_profiles.get(task.country_code)
        languages = profile.languages_for(task.language_code)
        tokens = self._distinctive_tokens(task.main_text, max_tokens=7)
        parts: list[str] = []
        if task.ean:
            parts.append(task.ean)
        parts.extend(tokens)
        if task.retailer_name:
            parts.append(task.retailer_name)
        if not global_fallback:
            # Use country context terms instead of only site:.xx. This helps CH,
            # multilingual countries, and retailers using several language paths.
            parts.extend(self.country_profiles.country_context_terms(task.country_code, languages[0])[:4])
            parts.extend(self._country_filter_terms(task, max_domain_hints=2))
        else:
            parts.append("global retailer product page")
        parts.extend(self._localized_buy_terms(task, languages[0], max_terms=4))
        return self._truncate(" ".join(parts))

    def repair_from_state(self, state: ProductSearchState, *, global_fallback: bool = False) -> str:
        task = state.task
        best = state.best_scorecard()
        clues: list[str] = []
        if best and best.scrape:
            s = best.scrape
            for value in [s.page_product_name, s.brand, s.manufacturer, s.h1, s.title]:
                if value:
                    clues.extend(self._distinctive_tokens(value, max_tokens=4))
        if not clues:
            clues = self._distinctive_tokens(task.main_text, max_tokens=6)
        parts = []
        seen = set()
        if task.ean:
            parts.append(task.ean)
            seen.add(task.ean.lower())
        for token in clues:
            key = token.lower()
            if key not in seen:
                seen.add(key)
                parts.append(token)
            if len(parts) >= 9:
                break
        if task.retailer_name:
            parts.append(task.retailer_name)
        if not global_fallback:
            parts.extend(self._country_filter_terms(task, max_domain_hints=3))
        else:
            parts.append("global product page")
        parts.extend(self._localized_buy_terms(task, task.language_code, max_terms=3))
        return self._truncate(" ".join(parts))

    def ai_validation_prompt(self, task: ProductQuery, candidates: list[URLCandidate], *, allow_global_fallback: bool = True) -> str:
        profile = self.country_profiles.get(task.country_code)
        language_line = ", ".join(profile.languages_for(task.language_code))
        local_domains = ", ".join(profile.retailer_domains[:12]) or "not configured"
        lines = [
            "You are validating ecommerce product URL candidates for a product evidence harness.",
            "Decision policy:",
            "1. Prefer exact product detail pages from the requested country.",
            "2. Treat EAN/GTIN as the strongest identity signal. If provided, a matching EAN beats title-only evidence.",
            "3. If no requested-country retailer/product page is available, a global fallback URL is allowed but must be marked as fallback evidence.",
            "4. Reject category/search/home pages as final product URLs unless no PDP exists.",
            "Return concise evidence only.",
            "Use FINAL_URL: <url> if one candidate is the best match, else FINAL_URL: NO_MATCH.",
            "Also state EAN_EVIDENCE, TITLE_EVIDENCE, RETAILER_EVIDENCE, COUNTRY_EVIDENCE, PRODUCT_PAGE_EVIDENCE, FALLBACK_REASON.",
            "",
            "PRODUCT:",
            f"main_text: {task.main_text}",
            f"country_code: {task.country_code}",
            f"country_languages: {language_line}",
            f"configured_country_retailer_domains: {local_domains}",
            f"retailer_name: {task.retailer_name or 'not_provided'}",
            f"ean_gtin: {task.ean or 'not_provided'}",
            f"global_fallback_allowed: {str(allow_global_fallback)}",
            "",
            "CANDIDATES:",
        ]
        for idx, c in enumerate(candidates[:12], start=1):
            country_specific = self.country_profiles.domain_matches_country(c.url, task.country_code)
            lines.extend([
                f"{idx}. url: {c.url}",
                f"   country_specific_domain: {country_specific}",
                f"   title: {c.title[:180]}",
                f"   snippet: {c.snippet[:240]}",
                f"   source_types: {', '.join(c.source_types)}",
            ])
        return self._truncate("\n".join(lines))

    def _country_filter_terms(self, task: ProductQuery, *, max_domain_hints: int = 4) -> list[str]:
        hints = list(self.country_profiles.country_hints(task.country_code, retailer_name=task.retailer_name, max_domain_hints=max_domain_hints))
        if not hints:
            return []
        # OR grouping preserves the country-specific restriction while supporting
        # multiple TLDs/retailer domains like CH: .ch, .swiss, galaxus.ch, etc.
        if len(hints) == 1:
            return hints
        return ["(" + " OR ".join(hints[: max_domain_hints + 2]) + ")"]

    def _localized_buy_terms(self, task: ProductQuery, language_code: str | None, *, max_terms: int) -> list[str]:
        profile = self.country_profiles.get(task.country_code)
        terms = profile.buy_terms_for(language_code, max_terms=max_terms)
        if not terms:
            return ["buy"]
        if len(terms) == 1:
            return [terms[0]]
        return ["(" + " OR ".join(terms) + ")"]

    def _quote(self, text: str) -> str:
        return f'"{text.strip().replace(chr(34), "")}"'

    def _distinctive_tokens(self, text: str, *, max_tokens: int) -> list[str]:
        stop = {"with", "from", "and", "the", "toy", "toys", "figure", "figurka", "set", "pack", "pcs", "ks"}
        tokens = [t for t in re.findall(r"[a-zA-Z0-9À-ž]+", text or "") if len(t) >= 3 and t.lower() not in stop]
        # Preserve model/SKU-like high-signal tokens first.
        model = [t for t in tokens if re.search(r"[A-Za-z]", t) and re.search(r"\d", t)]
        rest = [t for t in tokens if t not in model]
        seen: set[str] = set()
        out: list[str] = []
        for token in model + rest:
            key = token.lower()
            if key not in seen:
                seen.add(key)
                out.append(token)
            if len(out) >= max_tokens:
                break
        return out

    def _truncate(self, query: str) -> str:
        query = " ".join(str(query).split())
        if len(query) <= self.max_query_chars:
            return query
        return query[: self.max_query_chars].rsplit(" ", 1)[0]
