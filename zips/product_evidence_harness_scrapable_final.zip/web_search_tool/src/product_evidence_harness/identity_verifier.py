from __future__ import annotations

import re
import unicodedata
from dataclasses import dataclass
from typing import Optional
from urllib.parse import urlparse

from loguru import logger

from product_evidence_harness.config import HarnessPolicy
from product_evidence_harness.constants import (
    CHECK_ABSENT,
    CHECK_CONFLICT,
    CHECK_MATCHED,
    CHECK_NOT_APPLICABLE,
    CHECK_NOT_PROVIDED,
    CHECK_PARTIAL,
    CHECK_STRONG,
    CHECK_UNKNOWN,
    CHECK_WEAK,
    IDENTITY_MISMATCH,
    IDENTITY_PROBABLE,
    IDENTITY_UNVERIFIED,
    IDENTITY_VERIFIED,
    IDENTITY_WEAK,
    LISTING_URL_HINTS,
    PAGE_TYPE_LISTING,
    PAGE_TYPE_NON_PRODUCT,
    PAGE_TYPE_PRODUCT_DETAIL,
    PAGE_TYPE_SOFT_404,
    PAGE_TYPE_UNKNOWN,
    PRODUCT_URL_HINTS,
    QUANTITY_REGEX,
    TITLE_STOPWORDS,
    TOKEN_REGEX,
)
from product_evidence_harness.contracts import MatchVerification, ProductQuery, ScrapeResult


def _fold(text: str) -> str:
    decomposed = unicodedata.normalize("NFKD", text or "")
    return "".join(ch for ch in decomposed if not unicodedata.combining(ch)).lower()


@dataclass(frozen=True)
class ProductIdentityVerifier:
    policy: HarnessPolicy = HarnessPolicy()

    def verify(self, product: ProductQuery, scrape: Optional[ScrapeResult]) -> MatchVerification:
        if scrape is None or not scrape.scraped:
            return self._unverified(scrape.url if scrape else "", "page was not scraped")

        page_text = scrape.verification_text or " ".join([scrape.page_product_name, scrape.title, scrape.h1, scrape.markdown_excerpt])
        page_name = " ".join([scrape.page_product_name, scrape.title, scrape.h1, self._slug(scrape.final_url or scrape.url)])

        ean_check, page_eans = self._check_ean(product, scrape, page_text)
        qty_check, req_qty, page_qty = self._check_quantity(product, page_name)
        title_check, title_score, matched, missing = self._check_title(product, page_name)
        brand_check = self._check_brand(product, page_name)
        page_type = self._page_type(scrape)

        justifications: list[str] = []
        blockers: list[str] = []

        if ean_check == CHECK_MATCHED:
            justifications.append(f"EAN/GTIN {product.ean} confirmed")
        elif ean_check == CHECK_CONFLICT:
            msg = f"page declares different GTIN(s): {', '.join(page_eans)}"
            if self.policy.allow_ean_conflict:
                justifications.append(f"warning: {msg}")
            else:
                blockers.append(msg)

        if qty_check == CHECK_MATCHED:
            justifications.append(f"pack size matches ({req_qty})")
        elif qty_check == CHECK_CONFLICT:
            msg = f"pack size conflict: requested {req_qty}, page {page_qty}"
            if self.policy.allow_pack_size_mismatch:
                justifications.append(f"warning: {msg}")
            else:
                blockers.append(msg)

        if title_check == CHECK_STRONG:
            justifications.append(f"strong title token overlap ({len(matched)}/{max(1, len(matched)+len(missing))})")
        elif title_check == CHECK_PARTIAL:
            justifications.append(f"partial title token overlap ({len(matched)}/{max(1, len(matched)+len(missing))})")
        else:
            blockers.append("distinctive title tokens did not match")

        if page_type == PAGE_TYPE_SOFT_404:
            blockers.append("soft-404/product-not-found page")
        elif page_type in {PAGE_TYPE_NON_PRODUCT, PAGE_TYPE_LISTING}:
            blockers.append(f"not a product detail page ({page_type})")

        status = self._decide(
            scrape=scrape,
            ean_check=ean_check,
            quantity_check=qty_check,
            title_check=title_check,
            page_type=page_type,
            blockers=blockers,
        )
        verification = MatchVerification(
            url=scrape.url,
            identity_status=status,
            ean_check=ean_check,
            title_check=title_check,
            quantity_check=qty_check,
            brand_check=brand_check,
            page_type_check=page_type,
            title_match_score=title_score,
            requested_quantity=req_qty,
            page_quantity=page_qty,
            requested_ean=product.ean,
            page_eans=tuple(page_eans),
            matched_tokens=tuple(matched),
            missing_tokens=tuple(missing),
            justifications=tuple(justifications),
            blocking_reasons=tuple(blockers),
        )
        logger.info("Identity verification | status={} | ean={} | qty={} | title={} | page={} | url={}", status, ean_check, qty_check, title_check, page_type, scrape.url)
        return verification

    def _decide(self, *, scrape: ScrapeResult, ean_check: str, quantity_check: str, title_check: str, page_type: str, blockers: list[str]) -> str:
        if not scrape.is_scrapable:
            return IDENTITY_UNVERIFIED
        if blockers:
            return IDENTITY_MISMATCH
        if ean_check == CHECK_MATCHED and title_check in {CHECK_STRONG, CHECK_PARTIAL}:
            return IDENTITY_VERIFIED
        if title_check == CHECK_STRONG and quantity_check in {CHECK_MATCHED, CHECK_NOT_APPLICABLE, CHECK_UNKNOWN} and page_type in {PAGE_TYPE_PRODUCT_DETAIL, PAGE_TYPE_UNKNOWN}:
            return IDENTITY_VERIFIED
        if title_check == CHECK_STRONG:
            return IDENTITY_PROBABLE
        if title_check == CHECK_PARTIAL:
            return IDENTITY_WEAK
        return IDENTITY_UNVERIFIED

    def _check_ean(self, product: ProductQuery, scrape: ScrapeResult, page_text: str) -> tuple[str, list[str]]:
        if not product.ean:
            return CHECK_NOT_PROVIDED, []
        requested = re.sub(r"\D", "", product.ean)
        structured = [re.sub(r"\D", "", x) for x in scrape.structured_eans if re.sub(r"\D", "", x)]
        text_digits = re.sub(r"\D", "", page_text or "")
        if requested in structured or requested in text_digits:
            return CHECK_MATCHED, [requested]
        if structured:
            return CHECK_CONFLICT, structured
        return CHECK_ABSENT, []

    def _check_quantity(self, product: ProductQuery, page_name: str) -> tuple[str, Optional[str], Optional[str]]:
        requested = self._extract_qty(product.main_text)
        if requested is None:
            return CHECK_NOT_APPLICABLE, None, None
        page_qty = self._extract_qty(page_name)
        requested_label = f"{requested[0]} {requested[1]}"
        if page_qty is None:
            return CHECK_UNKNOWN, requested_label, None
        page_label = f"{page_qty[0]} {page_qty[1]}"
        return (CHECK_MATCHED if requested[0] == page_qty[0] else CHECK_CONFLICT), requested_label, page_label

    def _check_title(self, product: ProductQuery, page_name: str) -> tuple[str, float, list[str], list[str]]:
        tokens = self._tokens(product.main_text)
        if not tokens:
            return CHECK_WEAK, 0.0, [], []
        folded_page = _fold(page_name)
        matched = [t for t in tokens if t in folded_page]
        missing = [t for t in tokens if t not in folded_page]
        score = round(len(matched) / max(1, len(tokens)), 4)
        if score >= 0.75:
            level = CHECK_STRONG
        elif score >= self.policy.min_title_overlap:
            level = CHECK_PARTIAL
        else:
            level = CHECK_WEAK
        return level, score, matched, missing

    def _check_brand(self, product: ProductQuery, page_name: str) -> str:
        tokens = self._tokens(product.main_text)
        if not tokens:
            return CHECK_NOT_APPLICABLE
        return CHECK_MATCHED if tokens[0] in _fold(page_name) else CHECK_ABSENT

    def _page_type(self, scrape: ScrapeResult) -> str:
        if scrape.is_soft_404:
            return PAGE_TYPE_SOFT_404
        url = (scrape.final_url or scrape.url or "").lower()
        if any(h in url for h in LISTING_URL_HINTS):
            return PAGE_TYPE_LISTING
        if scrape.looks_like_product_page or any(h in url for h in PRODUCT_URL_HINTS):
            return PAGE_TYPE_PRODUCT_DETAIL
        if scrape.looks_like_homepage:
            return PAGE_TYPE_NON_PRODUCT
        return PAGE_TYPE_UNKNOWN

    def _extract_qty(self, text: str) -> Optional[tuple[str, str]]:
        m = re.search(QUANTITY_REGEX, _fold(text or ""), flags=re.I)
        if not m:
            return None
        return m.group(1), m.group(2).lower()

    def _tokens(self, text: str) -> list[str]:
        folded = _fold(text)
        tokens = []
        for token in re.findall(TOKEN_REGEX, folded):
            if len(token) < 3 or token in TITLE_STOPWORDS or token.isdigit():
                continue
            tokens.append(token)
        return list(dict.fromkeys(tokens))[:12]

    def _slug(self, url: str) -> str:
        return re.sub(r"[-_/]+", " ", urlparse(url or "").path)

    def _unverified(self, url: str, reason: str) -> MatchVerification:
        return MatchVerification(
            url=url,
            identity_status=IDENTITY_UNVERIFIED,
            ean_check=CHECK_UNKNOWN,
            title_check=CHECK_WEAK,
            quantity_check=CHECK_UNKNOWN,
            brand_check=CHECK_UNKNOWN,
            page_type_check=PAGE_TYPE_UNKNOWN,
            title_match_score=0.0,
            blocking_reasons=(reason,),
        )
