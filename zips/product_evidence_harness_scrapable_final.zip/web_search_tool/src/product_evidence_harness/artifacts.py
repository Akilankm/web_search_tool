from __future__ import annotations

import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from product_evidence_harness.contracts import ProductSearchState


@dataclass(frozen=True)
class ArtifactWriter:
    root_dir: str | Path

    def write_state(self, state: ProductSearchState) -> Path:
        product_dir = Path(self.root_dir) / self._safe(state.task.row_id)
        product_dir.mkdir(parents=True, exist_ok=True)
        self._write_json(product_dir / "task.json", state.task.to_dict())
        self._write_jsonl(product_dir / "action_trace.jsonl", [a.to_dict() for a in state.actions_taken])
        self._write_jsonl(product_dir / "candidates.jsonl", [c.to_dict() for c in state.candidates])
        self._write_jsonl(product_dir / "scrapes.jsonl", [s.to_dict() for s in state.scrapes.values()])
        self._write_jsonl(product_dir / "evidence_cards.jsonl", [e.to_dict() for e in state.evidence_cards])
        self._write_jsonl(product_dir / "verifications.jsonl", [v.to_dict() for v in state.verifications.values()])
        self._write_jsonl(product_dir / "scorecards.jsonl", [s.to_dict() for s in state.scorecards])
        if state.final_result:
            self._write_json(product_dir / "final_decision.json", state.final_result.to_dict())
        self._write_markdown(product_dir / "product_evidence.md", state)
        return product_dir

    def _write_json(self, path: Path, obj: Any) -> None:
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    def _write_jsonl(self, path: Path, rows: list[dict[str, Any]]) -> None:
        path.write_text("\n".join(json.dumps(row, ensure_ascii=False, default=str) for row in rows), encoding="utf-8")

    def _write_markdown(self, path: Path, state: ProductSearchState) -> None:
        lines = [f"# Product Evidence: {state.task.row_id}", "", f"**Input:** {state.task.main_text}", ""]
        if state.final_result:
            lines.extend([
                "## Final Decision",
                f"- URL: {state.final_result.product_url}",
                f"- Status: {state.final_result.validation_status}",
                f"- Confidence: {state.final_result.confidence}",
                f"- Justification: {state.final_result.justification}",
                "",
            ])
        lines.append("## Evidence Cards")
        for e in state.evidence_cards:
            lines.extend([
                f"### {e.source_url}",
                f"- Title: {e.product_title or ''}",
                f"- Brand: {e.brand or ''}",
                f"- EAN: {e.ean or ''}",
                f"- Confidence: {e.confidence}",
                "",
                e.description[:1000] if e.description else "",
                "",
            ])
        path.write_text("\n".join(lines), encoding="utf-8")

    def _safe(self, value: str) -> str:
        return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value)[:120]
