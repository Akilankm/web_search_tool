from __future__ import annotations

from dataclasses import dataclass

from product_evidence_harness.config import HarnessPolicy
from product_evidence_harness.constants import (
    COUNTRY_ALTERNATIVE,
    COUNTRY_MATCHED,
    COUNTRY_NOT_PROVIDED,
    IDENTITY_UNVERIFIED,
    RETAILER_NOT_PROVIDED,
    VALIDATION_NEEDS_REVIEW,
    VALIDATION_NO_MATCH,
    VALIDATION_REJECTED,
    VALIDATION_VERIFIED,
)
from product_evidence_harness.contracts import CandidateScorecard, ProductQuery, ProductURLMatch


@dataclass(frozen=True)
class FinalSelector:
    policy: HarnessPolicy = HarnessPolicy()

    def select(self, *, task: ProductQuery, scorecards: list[CandidateScorecard], termination_reason: str | None, budget_snapshot) -> ProductURLMatch:
        selected = self._select_card(scorecards)
        if not selected:
            return ProductURLMatch(
                row_id=task.row_id,
                main_text=task.main_text,
                country_code=task.country_code,
                retailer_name=task.retailer_name,
                ean=task.ean,
                product_url=None,
                confidence=0.0,
                validation_status=VALIDATION_NO_MATCH,
                identity_status=IDENTITY_UNVERIFIED,
                is_exact_product_match=False,
                match_reason="No acceptable candidate URL found",
                justification="No candidate passed the harness selection policy.",
                termination_reason=termination_reason,
                organic_calls_used=budget_snapshot.organic_used,
                ai_mode_calls_used=budget_snapshot.ai_mode_used,
                scrape_calls_used=budget_snapshot.scrape_used,
            )
        scrape = selected.scrape
        verification = selected.verification
        final_status = selected.validation_status
        if final_status == VALIDATION_REJECTED:
            final_status = VALIDATION_NEEDS_REVIEW
        reasons = list(selected.ranking_reasons)
        if selected.hard_failures:
            reasons.append("hard_failures=" + "; ".join(selected.hard_failures))
        if selected.soft_warnings:
            reasons.append("warnings=" + "; ".join(selected.soft_warnings))
        justification = " | ".join(reasons) or selected.candidate.evidence_text()[:500]
        return ProductURLMatch(
            row_id=task.row_id,
            main_text=task.main_text,
            country_code=task.country_code,
            retailer_name=task.retailer_name,
            ean=task.ean,
            product_url=selected.candidate.url,
            confidence=selected.final_confidence,
            validation_status=final_status,
            identity_status=verification.identity_status if verification else IDENTITY_UNVERIFIED,
            is_exact_product_match=final_status == VALIDATION_VERIFIED,
            match_reason="; ".join(selected.ranking_reasons[:5]),
            justification=justification,
            ean_check=verification.ean_check if verification else "UNKNOWN",
            title_check=verification.title_check if verification else "UNKNOWN",
            quantity_check=verification.quantity_check if verification else "UNKNOWN",
            page_type_check=verification.page_type_check if verification else "UNKNOWN",
            retailer_check=selected.retailer_check,
            country_check=selected.country_check,
            requested_quantity=verification.requested_quantity if verification else None,
            page_quantity=verification.page_quantity if verification else None,
            blocking_reasons="; ".join(verification.blocking_reasons if verification else selected.hard_failures),
            hard_failures=selected.hard_failures,
            soft_warnings=selected.soft_warnings,
            termination_reason=termination_reason,
            organic_calls_used=budget_snapshot.organic_used,
            ai_mode_calls_used=budget_snapshot.ai_mode_used,
            scrape_calls_used=budget_snapshot.scrape_used,
            is_scrapable=bool(scrape and scrape.is_scrapable),
            scrape_status_code=scrape.status_code if scrape else None,
            scrape_word_count=scrape.word_count if scrape else 0,
            scrape_markdown_chars=scrape.markdown_chars if scrape else 0,
            scrape_final_url=scrape.final_url if scrape else None,
            richness_score=scrape.richness_score if scrape else 0.0,
            price=scrape.price if scrape else None,
            currency=scrape.currency if scrape else "",
            brand=scrape.brand if scrape else "",
            manufacturer=scrape.manufacturer if scrape else "",
            description=scrape.description if scrape else "",
            specs_count=len(scrape.specs) if scrape else 0,
            image_count=scrape.image_count if scrape else 0,
            specs=dict(scrape.specs) if scrape else {},
            image_urls=tuple(scrape.image_urls) if scrape else (),
        )

    def _is_final_usable(self, card: CandidateScorecard) -> bool:
        """Final URL gate: only a successfully scraped, reachable, scrapable product page can be selected."""
        scrape = card.scrape
        if not scrape:
            return False
        if not (scrape.scraped and scrape.success and scrape.reachable and scrape.is_scrapable):
            return False
        if card.hard_failures:
            return False
        return True

    def _select_card(self, scorecards: list[CandidateScorecard]) -> CandidateScorecard | None:
        if not scorecards:
            return None

        country_cards = [
            card for card in scorecards
            if card.country_check in {COUNTRY_MATCHED, COUNTRY_NOT_PROVIDED}
        ]
        global_cards = [card for card in scorecards if card.country_check == COUNTRY_ALTERNATIVE]

        # Pass 1: verified, scrapable, country-specific/non-country-scoped PDP.
        for card in country_cards:
            if card.validation_status == VALIDATION_VERIFIED and self._is_final_usable(card):
                return card

        # Pass 2: reviewable country-specific candidate. This enforces the rule:
        # do not select global fallback while usable country-specific evidence exists.
        if self.policy.require_country_specific_before_global:
            for card in country_cards:
                if (
                    card.validation_status in {VALIDATION_VERIFIED, VALIDATION_NEEDS_REVIEW}
                    and self._is_final_usable(card)
                    and card.final_confidence >= self.policy.min_review_confidence
                ):
                    return card

        # Pass 3: global fallback, only when explicitly allowed.
        if self.policy.allow_global_fallback:
            for card in global_cards:
                if (
                    card.validation_status in {VALIDATION_VERIFIED, VALIDATION_NEEDS_REVIEW}
                    and self._is_final_usable(card)
                    and card.final_confidence >= self.policy.min_review_confidence
                ):
                    return card

        # Pass 4: any reviewable scrapable candidate with no hard failures.
        for card in scorecards:
            if self._is_final_usable(card) and card.final_confidence >= self.policy.min_review_confidence:
                return card

        # No AI-only / unscraped / non-scrapable final URL is allowed.
        # Such URLs remain available in the trace as candidates, but the final
        # ProductURLMatch must be usable by downstream scraping/coding stages.
        return None
