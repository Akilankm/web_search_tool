from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

import pandas as pd

from product_evidence_harness.contracts import ProductQuery, ProductURLMatch


_COLUMN_ALIASES = {
    "row_id": ["row_id", "ROW_ID", "ID", "id", "serial_id", "SERIAL_ID"],
    "main_text": ["MAIN_TEXT", "main_text", "Main Text", "product_text", "PRODUCT_TEXT"],
    "country_code": ["COUNTRY", "country", "COUNTRY_CODE", "country_code", "Country Code"],
    "retailer_name": ["RETAILER", "retailer", "RETAILER_NAME", "retailer_name", "Retailer Name"],
    "ean": ["EAN", "ean", "GTIN", "gtin", "barcode", "BARCODE"],
    "language_code": ["LANGUAGE", "language", "LANGUAGE_CODE", "language_code", "lang", "hl"],
    "region": ["REGION", "region", "market", "MARKET"],
}


def _get(row: Any, logical_name: str, default: Any = None) -> Any:
    for col in _COLUMN_ALIASES[logical_name]:
        try:
            value = row.get(col)
        except Exception:
            value = None
        if value is not None and str(value).strip() != "":
            return value
    return default


@dataclass(frozen=True)
class CSVProductIO:
    @staticmethod
    def read_products(path: str | Path) -> list[ProductQuery]:
        df = pd.read_csv(path) if str(path).lower().endswith(".csv") else pd.read_excel(path)
        products: list[ProductQuery] = []
        for idx, row in df.iterrows():
            products.append(ProductQuery(
                row_id=str(_get(row, "row_id", f"row-{idx+1}")),
                main_text=_get(row, "main_text"),
                country_code=_get(row, "country_code"),
                retailer_name=_get(row, "retailer_name"),
                ean=_get(row, "ean"),
                language_code=_get(row, "language_code"),
                region=_get(row, "region"),
            ))
        return products

    @staticmethod
    def write_matches(path: str | Path, matches: Iterable[ProductURLMatch]) -> None:
        rows = [m.to_dict() for m in matches]
        pd.DataFrame(rows).to_csv(path, index=False)
