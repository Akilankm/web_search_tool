from __future__ import annotations

from dataclasses import dataclass, field

from product_evidence_harness.config import HarnessConfig
from product_evidence_harness.constants import TERMINATION_BUDGET_EXHAUSTED, TERMINATION_VERIFIED
from product_evidence_harness.contracts import ActionType, AgentAction, ProductSearchState
from product_evidence_harness.country_profiles import CountryProfileRegistry
from product_evidence_harness.query_builder import QueryBuilder


@dataclass(frozen=True)
class HarnessPlanner:
    """Rule-based bounded planner for search/scrape feedback.

    The planner prioritizes requested-country candidates first. It only triggers
    a global organic fallback when the current candidate pool has no country-
    specific candidates and policy allows fallback.
    """

    config: HarnessConfig
    query_builder: QueryBuilder
    country_profiles: CountryProfileRegistry = field(default_factory=CountryProfileRegistry.load)

    def next_action(self, state: ProductSearchState) -> AgentAction:
        best = state.best_scorecard()
        if best and best.validation_status == "VERIFIED" and best.scrape and best.scrape.is_scrapable:
            return AgentAction(ActionType.FINISH, TERMINATION_VERIFIED)

        # First action: country-scoped high-precision search.
        if state.budget.organic_used == 0 and state.budget.can_search_organic():
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "initial country-specific high-precision product search",
                query=self.query_builder.primary(state.task, global_fallback=False),
                metadata={"kind": "primary", "scope": "country"},
            )

        # Scrape best country-specific candidate before spending more searches.
        next_country_url = self._next_unscraped_url(state, country_specific=True)
        if next_country_url and self.config.scrape_enabled and state.budget.can_scrape():
            return AgentAction(
                ActionType.SCRAPE_URL,
                "scrape highest-priority country-specific candidate",
                url=next_country_url,
                metadata={"scope": "country"},
            )

        # Second country search: language/retailer-aware recall query.
        if state.budget.organic_used == 1 and state.budget.can_search_organic() and self._has_country_candidates(state):
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "secondary country-specific multilingual/retailer-aware recall search",
                query=self.query_builder.secondary(state.task, global_fallback=False),
                metadata={"kind": "secondary", "scope": "country"},
            )

        # If country search found nothing usable, allow global fallback search.
        if (
            self.config.policy.allow_global_fallback
            and state.budget.can_search_organic()
            and not self._has_country_candidates(state)
        ):
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "global fallback search because no country-specific candidate is available",
                query=self.query_builder.primary(state.task, global_fallback=True),
                metadata={"kind": "global_fallback", "scope": "global"},
            )

        # Scrape global candidates only after country-specific candidates are exhausted.
        next_global_url = self._next_unscraped_url(state, country_specific=False)
        if next_global_url and self.config.scrape_enabled and state.budget.can_scrape():
            return AgentAction(
                ActionType.SCRAPE_URL,
                "scrape global/alternative candidate after country-specific candidates are exhausted",
                url=next_global_url,
                metadata={"scope": "global_or_alternative"},
            )

        # Use AI Mode for validation/repair across current candidate pool.
        if state.candidates and state.budget.can_search_ai():
            prompt = self.query_builder.ai_validation_prompt(
                state.task,
                state.candidates[: self.config.max_candidates_for_ai],
                allow_global_fallback=self.config.policy.allow_global_fallback,
            )
            return AgentAction(ActionType.AI_MODE_SEARCH, "AI Mode validation/repair over candidate pool", query=prompt)

        # Last organic repair from scraped clues. If country candidates exist, keep it country-scoped.
        if state.budget.can_search_organic():
            global_fallback = self.config.policy.allow_global_fallback and not self._has_country_candidates(state)
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "repair search generated from scrape evidence",
                query=self.query_builder.repair_from_state(state, global_fallback=global_fallback),
                metadata={"kind": "repair", "scope": "global" if global_fallback else "country"},
            )

        if state.budget.exhausted():
            return AgentAction(ActionType.FINISH, TERMINATION_BUDGET_EXHAUSTED)
        return AgentAction(ActionType.FINISH, "no_more_actions")

    def _has_country_candidates(self, state: ProductSearchState) -> bool:
        return any(self.country_profiles.domain_matches_country(c.url, state.task.country_code) for c in state.candidates)

    def _next_unscraped_url(self, state: ProductSearchState, *, country_specific: bool) -> str | None:
        scraped = set(state.scrapes)
        # Prefer ranked candidates; fall back to candidate insertion order.
        ranked = [card.candidate for card in state.scorecards] or state.candidates
        for candidate in ranked:
            if candidate.url in scraped:
                continue
            is_country = self.country_profiles.domain_matches_country(candidate.url, state.task.country_code)
            if country_specific and is_country:
                return candidate.url
            if not country_specific and not is_country:
                return candidate.url
        return None
