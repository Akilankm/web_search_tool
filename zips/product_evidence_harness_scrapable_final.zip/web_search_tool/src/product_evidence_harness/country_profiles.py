from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass, field
from functools import cached_property
from pathlib import Path
from typing import Any, Iterable, Optional
from urllib.parse import urlparse

PROFILE_PATH_ENV = "PRODUCT_HARNESS_COUNTRY_PROFILES"
DEFAULT_PROFILE_FILE = Path(__file__).resolve().parent / "configs" / "country_profiles.json"


def _norm_country(code: str | None) -> str:
    return (code or "").strip().upper()


def _norm_lang(code: str | None) -> str:
    return (code or "").strip().lower()


def _norm_domain(domain: str | None) -> str:
    value = (domain or "").strip().lower()
    value = re.sub(r"^https?://", "", value)
    value = value.split("/", 1)[0]
    return value[4:] if value.startswith("www.") else value


@dataclass(frozen=True)
class RetailerProfile:
    name: str
    domains: tuple[str, ...] = ()
    aliases: tuple[str, ...] = ()
    languages: tuple[str, ...] = ()

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "RetailerProfile":
        return cls(
            name=str(data.get("name") or "").strip(),
            domains=tuple(_norm_domain(d) for d in data.get("domains", []) if _norm_domain(d)),
            aliases=tuple(str(a).strip() for a in data.get("aliases", []) if str(a).strip()),
            languages=tuple(_norm_lang(l) for l in data.get("languages", []) if _norm_lang(l)),
        )

    def matches_name(self, retailer_name: str | None) -> bool:
        if not retailer_name:
            return False
        folded = retailer_name.strip().lower()
        candidates = [self.name, *self.aliases]
        return any(c and (c.lower() in folded or folded in c.lower()) for c in candidates)


@dataclass(frozen=True)
class CountryProfile:
    country_code: str
    default_language: str = "en"
    languages: tuple[str, ...] = ("en",)
    tlds: tuple[str, ...] = ()
    country_names: tuple[str, ...] = ()
    buy_terms: dict[str, tuple[str, ...]] = field(default_factory=dict)
    retailers: tuple[RetailerProfile, ...] = ()

    @classmethod
    def from_dict(cls, country_code: str, data: dict[str, Any]) -> "CountryProfile":
        buy_terms = {
            _norm_lang(k): tuple(str(x).strip() for x in v if str(x).strip())
            for k, v in (data.get("buy_terms") or {}).items()
        }
        return cls(
            country_code=_norm_country(country_code),
            default_language=_norm_lang(data.get("default_language") or "en") or "en",
            languages=tuple(_norm_lang(x) for x in data.get("languages", ["en"]) if _norm_lang(x)),
            tlds=tuple(str(x).strip().lower() for x in data.get("tlds", []) if str(x).strip()),
            country_names=tuple(str(x).strip() for x in data.get("country_names", []) if str(x).strip()),
            buy_terms=buy_terms,
            retailers=tuple(RetailerProfile.from_dict(x) for x in data.get("retailers", []) if isinstance(x, dict)),
        )

    @cached_property
    def retailer_domains(self) -> tuple[str, ...]:
        domains: list[str] = []
        for retailer in self.retailers:
            domains.extend(retailer.domains)
        return tuple(dict.fromkeys(d for d in domains if d))

    def languages_for(self, requested_language: str | None = None) -> tuple[str, ...]:
        ordered: list[str] = []
        for lang in [_norm_lang(requested_language), self.default_language, *self.languages, "en"]:
            if lang and lang not in ordered:
                ordered.append(lang)
        return tuple(ordered)

    def buy_terms_for(self, language_code: str | None = None, *, max_terms: int = 6) -> tuple[str, ...]:
        terms: list[str] = []
        for lang in self.languages_for(language_code):
            terms.extend(self.buy_terms.get(lang, ()))
        # Always include English fallback terms, but keep country languages first.
        terms.extend(self.buy_terms.get("en", ()))
        out: list[str] = []
        for term in terms:
            clean = str(term).strip()
            if clean and clean.lower() not in {x.lower() for x in out}:
                out.append(clean)
            if len(out) >= max_terms:
                break
        return tuple(out)

    def matching_retailers(self, retailer_name: str | None) -> tuple[RetailerProfile, ...]:
        if not retailer_name:
            return ()
        return tuple(r for r in self.retailers if r.matches_name(retailer_name))

    def retailer_domains_for(self, retailer_name: str | None = None) -> tuple[str, ...]:
        if retailer_name:
            matched = self.matching_retailers(retailer_name)
            if matched:
                domains: list[str] = []
                for retailer in matched:
                    domains.extend(retailer.domains)
                return tuple(dict.fromkeys(domains))
        return self.retailer_domains


class CountryProfileRegistry:
    def __init__(self, profiles: dict[str, CountryProfile], default: CountryProfile) -> None:
        self._profiles = {_norm_country(k): v for k, v in profiles.items()}
        self._default = default

    @classmethod
    def load(cls, path: str | Path | None = None) -> "CountryProfileRegistry":
        resolved = Path(path or os.getenv(PROFILE_PATH_ENV) or DEFAULT_PROFILE_FILE)
        with resolved.open("r", encoding="utf-8") as f:
            payload = json.load(f)
        countries = payload.get("countries", payload)
        default_data = countries.get("DEFAULT", {})
        default = CountryProfile.from_dict("DEFAULT", default_data)
        profiles = {
            _norm_country(code): CountryProfile.from_dict(code, data)
            for code, data in countries.items()
            if _norm_country(code) != "DEFAULT" and isinstance(data, dict)
        }
        return cls(profiles=profiles, default=default)

    def get(self, country_code: str | None) -> CountryProfile:
        code = _norm_country(country_code)
        profile = self._profiles.get(code)
        if profile:
            return profile
        # Preserve requested country code while inheriting default language terms.
        return CountryProfile(
            country_code=code or "DEFAULT",
            default_language=self._default.default_language,
            languages=self._default.languages,
            tlds=(f".{code.lower()}",) if len(code) == 2 else self._default.tlds,
            country_names=self._default.country_names,
            buy_terms=self._default.buy_terms,
            retailers=(),
        )

    def domain_matches_country(self, url_or_domain: str, country_code: str | None) -> bool:
        profile = self.get(country_code)
        domain = _norm_domain(urlparse(url_or_domain).netloc or url_or_domain)
        if not domain:
            return False
        if any(domain == d or domain.endswith(f".{d}") for d in profile.retailer_domains):
            return True
        if any(domain.endswith(tld) for tld in profile.tlds):
            return True
        url_lower = (url_or_domain or "").lower()
        code = _norm_country(country_code).lower()
        return bool(code and (f"/{code}/" in url_lower or f"-{code}/" in url_lower or f"_{code}/" in url_lower))

    def country_hints(self, country_code: str | None, *, retailer_name: str | None = None, max_domain_hints: int = 4) -> tuple[str, ...]:
        profile = self.get(country_code)
        hints: list[str] = []
        # For CH-like countries this is better than site:.country_code because tlds can include .swiss.
        hints.extend(f"site:{tld}" for tld in profile.tlds)
        domains = profile.retailer_domains_for(retailer_name)[:max_domain_hints]
        hints.extend(f"site:{domain}" for domain in domains)
        return tuple(dict.fromkeys(hints))

    def country_context_terms(self, country_code: str | None, language_code: str | None = None) -> tuple[str, ...]:
        profile = self.get(country_code)
        terms: list[str] = []
        terms.extend(profile.country_names[:3])
        terms.extend(profile.buy_terms_for(language_code, max_terms=4))
        return tuple(dict.fromkeys(t for t in terms if t))
