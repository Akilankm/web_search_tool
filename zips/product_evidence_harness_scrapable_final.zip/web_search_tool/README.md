# Product Evidence Harness

This repo is a **bounded search-scrape harness** for product URL discovery and product evidence extraction.

It is intentionally **not** an AzureML component yet. It is a local Python package that can be run from scripts or notebooks.

## Required input rules

Each product task requires:

| Field | Required | Rule |
|---|---:|---|
| `main_text` | Yes | Primary product text / product name from input data. |
| `country_code` | Yes | ISO-like country code such as `CZ`, `CH`, `US`. Used for country-specific search and final selection. |
| `ean` / `gtin` | No | Strongest identity signal when provided. Matching EAN can verify identity; conflicting EAN blocks selection by default. |
| `retailer_name` | No | Narrows the search to a retailer/domain if provided. Otherwise the harness prefers country-specific retailers. |
| `language_code` | No | Optional override. If not supplied, language is inferred from `country_profiles.json`. |

## Core decision policy

```text
1. Search country-specific retailers/domains first.
2. Scrape country-specific candidates before global candidates.
3. Use EAN/GTIN as the strongest identity signal.
4. Select a global fallback only when no usable country-specific candidate exists.
5. Use AI Mode for validation/repair, not as final authority.
6. Final URL must be successfully scraped, reachable, and scrapable.
7. If no candidate passes the scrape gate, return `NO_MATCH` with `product_url=None`.
8. Final selection is deterministic: scrape evidence + identity verifier + ranker + selector policy.
```

## Country/language/retailer profiles

Country-specific behavior is configured here:

```text
src/product_evidence_harness/configs/country_profiles.json
```

The profile supports countries with multiple internal languages and country-specific retailer distributions.

Example: `CH` is configured with:

```text
languages: de, fr, it, rm, en
tlds: .ch, .swiss
buy terms: kaufen, acheter, comprare, cumprar, buy
retailer domains: galaxus.ch, digitec.ch, manor.ch, coop.ch, migros.ch, ...
```

You can edit this JSON directly or point to another file:

```python
config = HarnessConfig(
    country_profile_path="./configs/my_country_profiles.json",
)
```

or via environment variable:

```bash
export PRODUCT_HARNESS_COUNTRY_PROFILES=/path/to/country_profiles.json
```

## Core flow

```text
ProductQuery
  ↓
ProductSearchState
  ↓
BoundedHarnessLoop
  ├─ country organic_search
  ├─ scrape country candidate
  ├─ secondary multilingual/retailer-aware country search
  ├─ global fallback search only if no country candidate exists
  ├─ AI Mode validation/repair
  └─ finish
  ↓
CandidateScorecard ranking
  ↓
ProductURLMatch + optional artifact folder
```

## Final URL guarantee

The final `product_url` is not allowed to be AI-only, organic-only, unreachable, blocked, soft-404, or non-scrapable. Those URLs can still appear in the trace for debugging, but the final result returns a URL only after the scrape layer confirms it is usable.

If every candidate fails scraping, the result is:

```text
validation_status = NO_MATCH
product_url = None
is_scrapable = False
```

## Main package

```text
src/product_evidence_harness/
├── contracts.py          # ProductQuery, state, candidates, evidence, scorecards
├── country_profiles.py   # country/language/retailer profile registry
├── configs/
│   └── country_profiles.json
├── config.py             # SerpAPIConfig, HarnessConfig, HarnessPolicy, budget config
├── planner.py            # bounded next-action policy
├── executor.py           # executes search / AI / scrape actions
├── loop.py               # bounded agent loop
├── candidate_store.py    # candidate dedupe/merge from organic + AI Mode
├── query_builder.py      # EAN-first, multilingual, country-aware queries
├── scraper.py            # crawl4ai first, requests fallback
├── identity_verifier.py  # deterministic EAN/title/pack-size/page-type checks
├── ranker.py             # transparent scorecards + confidence caps
├── selector.py           # country-first final URL selection policy
├── artifacts.py          # JSONL/Markdown trace writer
└── pipeline.py           # ProductEvidenceHarness entrypoint
```

## Minimal usage

```python
from product_evidence_harness import ProductEvidenceHarness, ProductQuery, SerpAPIConfig, HarnessConfig

harness = ProductEvidenceHarness(
    serp_config=SerpAPIConfig.from_env(country_code="CH", language_code="de"),
    config=HarnessConfig(),
)

trace = harness.run(
    ProductQuery(
        row_id="demo-001",
        main_text="LEGO City Feuerwehrstation",
        country_code="CH",
        ean="5702011234567",
        retailer_name=None,
    ),
    return_trace=True,
)

print(trace.best_match.to_dict())
```

## Batch input columns

The CSV/XLSX reader accepts these aliases:

| Logical field | Accepted column names |
|---|---|
| `row_id` | `row_id`, `ROW_ID`, `ID`, `serial_id`, `SERIAL_ID` |
| `main_text` | `MAIN_TEXT`, `main_text`, `Main Text`, `product_text`, `PRODUCT_TEXT` |
| `country_code` | `COUNTRY`, `country`, `COUNTRY_CODE`, `country_code`, `Country Code` |
| `retailer_name` | `RETAILER`, `retailer`, `RETAILER_NAME`, `retailer_name`, `Retailer Name` |
| `ean` | `EAN`, `GTIN`, `barcode` |
| `language_code` | `LANGUAGE`, `LANGUAGE_CODE`, `language_code`, `lang`, `hl` |

## Useful notebooks

```text
notebooks/01_single_product_harness.ipynb
notebooks/02_batch_product_harness.ipynb
notebooks/03_country_profile_tuning.ipynb
```

## Local validation

```bash
python -m compileall -q src main.py batch_main.py
pytest -q
```

Expected current result:

```text
16 passed
```
