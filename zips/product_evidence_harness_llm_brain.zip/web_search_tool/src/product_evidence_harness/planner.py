from __future__ import annotations

from dataclasses import dataclass

from product_evidence_harness.config import HarnessConfig
from product_evidence_harness.constants import TERMINATION_BUDGET_EXHAUSTED, TERMINATION_VERIFIED
from product_evidence_harness.contracts import ActionType, AgentAction, LLMSearchQuery, ProductSearchState
from product_evidence_harness.country_profiles import CountryProfileRegistry
from product_evidence_harness.query_builder import QueryBuilder


@dataclass(frozen=True)
class HarnessPlanner:
    """LLM-guided bounded planner.

    If LLM search planning is enabled, the first action is LLM_SEARCH_PLAN.
    SerpAPI organic searches then execute LLM-planned queries. After candidates
    are scraped and judged weak, the LLM may provide one feedback/repair plan.
    Without LLM, deterministic country-language search behavior is used.
    """

    config: HarnessConfig
    query_builder: QueryBuilder
    country_profiles: CountryProfileRegistry

    def next_action(self, state: ProductSearchState) -> AgentAction:
        # Stop when a verified, usable candidate is already available.
        best = state.best_scorecard()
        if best and self._is_verified_usable(best):
            return AgentAction(ActionType.FINISH, TERMINATION_VERIFIED)

        # LLM as the brain: plan before SerpAPI if enabled and budget allows.
        if self.config.enable_llm_search_planning and not self._llm_stage_done(state, "initial_search_plan"):
            if self._llm_calls_remaining(state) > 1:  # keep at least one call for adjudication
                return AgentAction(ActionType.LLM_SEARCH_PLAN, "LLM creates country-first/global-fallback search plan", metadata={"kind": "llm_search_plan"})

        # Execute queued LLM-planned queries first.
        planned = self._next_planned_query(state)
        if planned and state.budget.can_search_organic():
            meta = {
                "kind": planned.source,
                "scope": planned.scope,
                "reason": planned.reason,
                "priority": planned.priority,
                "language_code": planned.language_code,
                "language_name": planned.language_name,
                "must_include_ean": planned.must_include_ean,
            }
            return AgentAction(ActionType.ORGANIC_SEARCH, planned.reason or "execute LLM-planned query", query=planned.query, metadata=meta)

        # Deterministic fallback search if LLM disabled/failed/no queued queries.
        if not self.config.enable_llm_search_planning:
            idx = self._next_country_language_index(state)
            if idx is not None and state.budget.can_search_organic():
                return AgentAction(
                    ActionType.ORGANIC_SEARCH,
                    "country/language-priority search",
                    query=self.query_builder.country_language_search(state.task, language_index=idx),
                    metadata=self.query_builder.country_language_metadata(state.task, idx),
                )

        # Scrape country-specific candidates first.
        next_country_url = self._next_unscraped_url(state, country_specific=True)
        if next_country_url and state.budget.can_scrape():
            return AgentAction(ActionType.SCRAPE_URL, "scrape country-specific candidate for evidence", url=next_country_url, metadata={"scope": "country"})

        # Feedback/refinement once current candidate pool is weak or country result is not exact/rich.
        if self._should_request_llm_feedback(state):
            return AgentAction(ActionType.LLM_SEARCH_FEEDBACK, "LLM reviews candidates/scrapes and refines search", metadata={"kind": "llm_search_feedback"})

        # Execute any queued feedback queries added by the previous action.
        planned = self._next_planned_query(state)
        if planned and state.budget.can_search_organic():
            return AgentAction(ActionType.ORGANIC_SEARCH, planned.reason or "execute LLM feedback query", query=planned.query, metadata={"kind": planned.source, "scope": planned.scope, "reason": planned.reason, "priority": planned.priority})

        # AI Mode remains an optional addon for URL discovery, not the brain.
        if self.config.budget.max_ai_mode_searches > 0 and state.budget.can_search_ai() and not self._ai_discovery_done(state) and not state.candidates:
            return AgentAction(
                ActionType.AI_MODE_SEARCH,
                "SerpAPI AI Mode addon discovery when organic candidates are empty",
                query=self.query_builder.ai_discovery_prompt(state.task, allow_global_fallback=self.config.policy.allow_global_fallback),
                metadata={"kind": "ai_discovery", "scope": "country_then_global"},
            )

        # Scrape global/alternative candidates after country options are exhausted.
        next_global_url = self._next_unscraped_url(state, country_specific=False)
        if next_global_url and state.budget.can_scrape():
            return AgentAction(ActionType.SCRAPE_URL, "scrape global/alternative fallback candidate", url=next_global_url, metadata={"scope": "global_or_alternative"})

        # Deterministic repair/global fallback if LLM budget is exhausted but search budget remains.
        if state.budget.can_search_organic() and not self._global_search_done(state):
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "deterministic global fallback search",
                query=self.query_builder.global_fallback(state.task),
                metadata={"kind": "global_fallback", "scope": "global"},
            )

        if state.budget.exhausted():
            return AgentAction(ActionType.FINISH, TERMINATION_BUDGET_EXHAUSTED)
        return AgentAction(ActionType.FINISH, "no_more_actions")

    def _is_verified_usable(self, card) -> bool:
        s = card.scrape
        v = card.verification
        if not s or not v:
            return False
        if not (s.scraped and s.success and s.reachable and s.is_scrapable and s.looks_like_product_page):
            return False
        if card.hard_failures:
            return False
        if self.config.policy.require_llm_exact_match_for_final or self.config.llm_require_exact_match_for_final:
            return card.llm_decision in {"EXACT_MATCH", "EXACT_MATCH_WITH_WARNING"} and card.llm_exact_product_match
        return (
            v.identity_status == "VERIFIED"
            and v.exact_product_check in {"EXACT_MATCH", "UNKNOWN"}
            and v.variant_check != "CONFLICT"
        )

    def _llm_calls_remaining(self, state: ProductSearchState) -> int:
        return max(0, self.config.llm_max_calls_per_product - len(state.llm_call_records))

    def _llm_stage_done(self, state: ProductSearchState, stage: str) -> bool:
        return any(p.stage == stage for p in state.llm_search_plans)

    def _next_planned_query(self, state: ProductSearchState) -> LLMSearchQuery | None:
        executed = set(state.queries)
        in_progress = {
            r.action.query for r in state.actions_taken
            if r.action.action_type == ActionType.ORGANIC_SEARCH and r.action.query
        }
        for query in sorted(state.planned_search_queries, key=lambda q: q.priority):
            if query.query not in executed and query.query not in in_progress:
                return query
        return None

    def _should_request_llm_feedback(self, state: ProductSearchState) -> bool:
        if not self.config.enable_llm_search_feedback:
            return False
        if self._llm_stage_done(state, "search_feedback"):
            return False
        if self._llm_calls_remaining(state) <= 1:
            return False
        if not state.candidates and state.budget.organic_used >= 1:
            return True
        if state.scrapes:
            # Ask for feedback when all scraped candidates are weak/non-exact/non-scrapable or country-only candidates failed.
            for card in state.scorecards[:5]:
                s = card.scrape
                if s and s.is_scrapable and s.looks_like_product_page and not card.hard_failures and card.validation_status == "VERIFIED":
                    return False
            return True
        # If planned queries are exhausted and candidates exist but none scraped yet, scrape first.
        return False

    def _next_unscraped_url(self, state: ProductSearchState, *, country_specific: bool) -> str | None:
        scraped = set(state.scrapes)
        ranked = [card.candidate for card in state.scorecards] or state.candidates
        for candidate in ranked:
            if candidate.url in scraped:
                continue
            is_country = self.country_profiles.domain_matches_country(candidate.url, state.task.country_code)
            if country_specific and is_country:
                return candidate.url
            if not country_specific and not is_country:
                return candidate.url
        return None

    def _next_country_language_index(self, state: ProductSearchState) -> int | None:
        done = {
            int(record.action.metadata.get("language_index"))
            for record in state.actions_taken
            if record.action.action_type == ActionType.ORGANIC_SEARCH
            and record.action.metadata.get("kind") == "country_language"
            and record.action.metadata.get("language_index") is not None
        }
        total = self.query_builder.country_language_count(state.task)
        reserve_for_fallback = 1 if self.config.policy.allow_global_fallback else 0
        max_language_searches = max(1, self.config.budget.max_organic_searches - reserve_for_fallback)
        for idx in range(min(total, max_language_searches)):
            if idx not in done:
                return idx
        return None

    def _global_search_done(self, state: ProductSearchState) -> bool:
        return any(r.action.action_type == ActionType.ORGANIC_SEARCH and r.action.metadata.get("kind") == "global_fallback" for r in state.actions_taken)

    def _ai_discovery_done(self, state: ProductSearchState) -> bool:
        return any(r.action.action_type == ActionType.AI_MODE_SEARCH and r.action.metadata.get("kind") == "ai_discovery" for r in state.actions_taken)
