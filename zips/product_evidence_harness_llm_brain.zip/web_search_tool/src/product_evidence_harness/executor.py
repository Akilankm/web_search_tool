from __future__ import annotations

from dataclasses import dataclass

from loguru import logger

from product_evidence_harness.candidate_store import CandidateStore
from product_evidence_harness.contracts import ActionType, AgentAction, ProductSearchState
from product_evidence_harness.evidence_extractor import EvidenceExtractor
from product_evidence_harness.identity_verifier import ProductIdentityVerifier
from product_evidence_harness.llm.search_planner import LLMSearchPlanner
from product_evidence_harness.ranker import ProductURLRanker
from product_evidence_harness.scraper import CrawlScraper
from product_evidence_harness.serp_clients import GoogleAIModeClient, GoogleOrganicSearchClient


@dataclass
class HarnessExecutor:
    organic_client: GoogleOrganicSearchClient
    ai_client: GoogleAIModeClient
    scraper: CrawlScraper
    candidate_store: CandidateStore
    verifier: ProductIdentityVerifier
    ranker: ProductURLRanker
    evidence_extractor: EvidenceExtractor
    llm_search_planner: LLMSearchPlanner | None = None

    def execute(self, action: AgentAction, state: ProductSearchState) -> dict:
        logger.info("Executing action | type={} | reason={}", action.action_type.value, action.reason)
        if action.action_type == ActionType.LLM_SEARCH_PLAN:
            return self._llm_search_plan(action, state)
        if action.action_type == ActionType.LLM_SEARCH_FEEDBACK:
            return self._llm_search_feedback(action, state)
        if action.action_type == ActionType.ORGANIC_SEARCH:
            return self._organic(action, state)
        if action.action_type == ActionType.AI_MODE_SEARCH:
            return self._ai(action, state)
        if action.action_type == ActionType.SCRAPE_URL:
            return self._scrape(action, state)
        if action.action_type == ActionType.FINISH:
            state.termination_reason = action.reason
            return {"finished": True, "reason": action.reason}
        raise ValueError(f"Unsupported action type: {action.action_type}")

    def refresh_scores(self, state: ProductSearchState) -> None:
        state.scorecards = self.ranker.score(
            product=state.task,
            candidates=state.candidates,
            scrapes=state.scrapes,
            verifications=state.verifications,
        )

    def _llm_search_plan(self, action: AgentAction, state: ProductSearchState) -> dict:
        if not self.llm_search_planner:
            raise ValueError("LLM search planner not configured")
        plan, record = self.llm_search_planner.plan_initial(state)
        state.llm_search_plans.append(plan)
        state.llm_call_records.append(record)
        state.planned_search_queries.extend(plan.queries)
        return {
            "stage": plan.stage,
            "success": plan.success,
            "queries_added": len(plan.queries),
            "expanded_main_text": plan.expanded_main_text,
            "reasoning": plan.reasoning,
            "error": plan.error,
        }

    def _llm_search_feedback(self, action: AgentAction, state: ProductSearchState) -> dict:
        if not self.llm_search_planner:
            raise ValueError("LLM search planner not configured")
        plan, record = self.llm_search_planner.plan_feedback(state)
        state.llm_search_plans.append(plan)
        state.llm_call_records.append(record)
        # Deduplicate against already executed or queued queries.
        existing = set(state.queries) | {q.query for q in state.planned_search_queries}
        added = []
        for q in plan.queries:
            if q.query not in existing:
                state.planned_search_queries.append(q)
                existing.add(q.query)
                added.append(q)
        return {
            "stage": plan.stage,
            "success": plan.success,
            "queries_added": len(added),
            "expanded_main_text": plan.expanded_main_text,
            "reasoning": plan.reasoning,
            "error": plan.error,
        }

    def _organic(self, action: AgentAction, state: ProductSearchState) -> dict:
        state.budget.consume_organic()
        response = self.organic_client.search(action.query or "", product=state.task)
        state.queries.append(action.query or "")
        state.organic_responses.append(response)
        before = len(state.candidates)
        state.candidates = self.candidate_store.merge_organic(state.candidates, response)
        self.refresh_scores(state)
        return {"query": action.query, "results": len(response.results), "candidates_before": before, "candidates_after": len(state.candidates)}

    def _ai(self, action: AgentAction, state: ProductSearchState) -> dict:
        state.budget.consume_ai()
        response = self.ai_client.search(action.query or "", product=state.task)
        state.queries.append(action.query or "")
        state.ai_responses.append(response)
        before = len(state.candidates)
        state.candidates = self.candidate_store.merge_ai(state.candidates, response)
        self.refresh_scores(state)
        return {"references": len(response.references), "candidates_before": before, "candidates_after": len(state.candidates)}

    def _scrape(self, action: AgentAction, state: ProductSearchState) -> dict:
        if not action.url:
            raise ValueError("scrape action requires url")
        state.budget.consume_scrape()
        scrape = self.scraper.scrape(action.url, product=state.task)
        state.scrapes[action.url] = scrape
        evidence = self.evidence_extractor.from_scrape(scrape)
        state.evidence_cards.append(evidence)
        verification = self.verifier.verify(state.task, scrape)
        state.verifications[action.url] = verification
        self.refresh_scores(state)
        return {"url": action.url, "scrapable": scrape.is_scrapable, "identity": verification.identity_status, "richness": scrape.richness_score}
