from __future__ import annotations

import csv

from product_evidence_harness import HarnessBudgetConfig, HarnessConfig, ProductEvidenceHarness, ProductQuery, SerpAPIConfig
from product_evidence_harness.contracts import OrganicSearchResponse, OrganicSearchResult, ScrapeResult, SerpAIResponse


class FakeOrganic:
    def search(self, query, *, product=None):
        return OrganicSearchResponse(
            query=query,
            search_id="fake",
            status="Success",
            results=[OrganicSearchResult(url="https://shop.cz/product/acme-widget-18-ks", title="Acme Widget 18 ks", snippet="Buy Acme Widget 18 ks", position=1, query=query)],
        )


class FakeAI:
    def search(self, query, *, product=None):
        return SerpAIResponse(query=query, status="Success", search_id="ai", markdown="")


class FakeScraper:
    def scrape(self, url, *, product=None):
        return ScrapeResult(
            url=url,
            scraped=True,
            success=True,
            reachable=True,
            is_scrapable=True,
            status_code=200,
            final_url=url,
            title="Acme Widget 18 ks",
            h1="Acme Widget 18 ks",
            page_product_name="Acme Widget 18 ks",
            richness_score=0.8,
            word_count=200,
            markdown_chars=1000,
            looks_like_product_page=True,
            verification_text="Acme Widget 18 ks add to cart",
        )


def test_per_row_csv_outputs_are_written(tmp_path):
    harness = ProductEvidenceHarness(
        serp_config=SerpAPIConfig(api_key="test"),
        config=HarnessConfig(
            budget=HarnessBudgetConfig(max_organic_searches=1, max_ai_mode_searches=0, max_scrapes=1, max_iterations=3),
            output_dir=str(tmp_path),
            write_outputs=True,
        ),
        organic_client=FakeOrganic(),
        ai_client=FakeAI(),
        scraper=FakeScraper(),
    )
    trace = harness.run(ProductQuery(row_id="row-001", main_text="Acme Widget 18 ks", country_code="CZ"), return_trace=True)

    row_dir = tmp_path / "row-001"
    for name in ["best_url.csv", "summary.csv", "candidates.csv", "scrapes.csv", "actions.csv", "queries.csv"]:
        assert (row_dir / name).exists()

    with (row_dir / "best_url.csv").open(newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    assert rows[0]["product_url"] == trace.best_match.product_url
    assert rows[0]["resolution_status"] == "RESOLVED"
