"""Single-product local demo for the LLM-guided Product Evidence Harness."""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

from product_evidence_harness import (  # noqa: E402
    HarnessConfig,
    ProductEvidenceHarness,
    ProductQuery,
    RichPrinter,
    SerpAPIConfig,
    configure_logging,
)

configure_logging("INFO")
printer = RichPrinter()

serp_config = SerpAPIConfig.from_env(country_code="CH", language_code="de", no_cache=False)
config = HarnessConfig.from_env(".env")
harness = ProductEvidenceHarness(serp_config=serp_config, config=config)

product = ProductQuery(
    row_id="demo-001",
    main_text="1001KARTENA5FLIEDER",
    country_code="CH",
    retailer_name=None,
    ean="7612450206555",
    language_code=None,
)

trace = harness.run(product, return_trace=True)
printer.print_match(trace.best_match)
printer.print_scorecards(trace.scored_candidates)
print("Per-row CSV outputs written under:", config.output_dir)
