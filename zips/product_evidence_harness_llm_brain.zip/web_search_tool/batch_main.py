"""Batch runner for the local product evidence harness."""

from __future__ import annotations

import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

import pandas as pd  # noqa: E402
from rich import print  # noqa: E402
from tqdm.auto import tqdm  # noqa: E402

from product_evidence_harness import (  # noqa: E402
    CSVProductIO,
    HarnessBudgetConfig,
    HarnessConfig,
    HarnessPolicy,
    ProductEvidenceHarness,
    SerpAPIConfig,
    configure_logging,
)

configure_logging("INFO")

INPUT_FILE = Path("./data/products.xlsx")
OUTPUT_FILE = Path("./outputs/product_url_matches.csv")
MAX_WORKERS = 4

# ProductQuery country/language overrides are passed per row. This default is
# only used when a row does not provide language_code.
serp_config = SerpAPIConfig.from_env(country_code="CH", language_code="de", no_cache=False)
config = HarnessConfig.from_env(".env")
harness = ProductEvidenceHarness(serp_config=serp_config, config=config)
products = CSVProductIO.read_products(INPUT_FILE)

print(f"[bold cyan]Loaded {len(products)} products[/bold cyan]")


def process(product):
    try:
        match = harness.run(product)
        return match.to_dict() | {"status": "success", "error": None}
    except Exception as exc:
        return {
            "row_id": product.row_id,
            "main_text": product.main_text,
            "country_code": product.country_code,
            "retailer_name": product.retailer_name,
            "ean": product.ean,
            "product_url": None,
            "confidence": 0.0,
            "validation_status": "ERROR",
            "identity_status": "ERROR",
            "status": "error",
            "error": str(exc),
        }


rows = []
with ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
    futures = [executor.submit(process, p) for p in products]
    for future in tqdm(as_completed(futures), total=len(futures), desc="Processing"):
        rows.append(future.result())

OUTPUT_FILE.parent.mkdir(parents=True, exist_ok=True)
pd.DataFrame(rows).to_csv(OUTPUT_FILE, index=False)
print(f"[bold green]Wrote {OUTPUT_FILE}[/bold green]")
