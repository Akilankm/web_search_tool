from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from product_evidence_harness.contracts import ActionType, CandidateScorecard, ProductSearchState
from product_evidence_harness.country_profiles import CountryProfileRegistry


@dataclass(frozen=True)
class ArtifactWriter:
    """Compact analytics-friendly per-row output writer.

    The default output is intentionally CSV-first and small. It writes enough
    information to understand why the best URL was selected or why no final URL
    was resolved, without dumping large markdown/page text.
    """

    root_dir: str | Path
    include_debug_json: bool = False
    country_profiles: CountryProfileRegistry = field(default_factory=CountryProfileRegistry.load)

    def write_state(self, state: ProductSearchState) -> Path:
        product_dir = Path(self.root_dir) / self._safe(state.task.row_id)
        product_dir.mkdir(parents=True, exist_ok=True)

        self._write_csv(product_dir / "best_url.csv", [self._best_row(state)])
        self._write_csv(product_dir / "summary.csv", [self._summary_row(state)])
        self._write_csv(product_dir / "candidates.csv", [self._candidate_row(state, c, idx) for idx, c in enumerate(state.scorecards, start=1)])
        self._write_csv(product_dir / "scrapes.csv", [self._scrape_row(url, s) for url, s in state.scrapes.items()])
        self._write_csv(product_dir / "actions.csv", [self._action_row(a) for a in state.actions_taken])
        self._write_csv(product_dir / "queries.csv", self._query_rows(state))
        self._write_csv(product_dir / "language_profile.csv", self._language_profile_rows(state))

        if self.include_debug_json:
            self._write_json(product_dir / "debug_state.json", state.to_dict())
        return product_dir

    def _best_row(self, state: ProductSearchState) -> dict[str, Any]:
        m = state.final_result
        if not m:
            return {"row_id": state.task.row_id, "resolution_status": "UNRESOLVED", "product_url": None}
        selected_language = self._selected_candidate_language(state)
        return {
            "row_id": m.row_id,
            "main_text": m.main_text,
            "country_code": m.country_code,
            "ean": m.ean,
            "retailer_name": m.retailer_name,
            "selected_language_code": selected_language.get("language_code"),
            "selected_language_name": selected_language.get("language_name"),
            "selected_language_priority": selected_language.get("language_priority"),
            "selected_language_distribution_weight": selected_language.get("language_distribution_weight"),
            "product_url": m.product_url,
            "resolution_status": m.resolution_status,
            "validation_status": m.validation_status,
            "identity_status": m.identity_status,
            "is_exact_product_match": m.is_exact_product_match,
            "is_scrapable": m.is_scrapable,
            "confidence": m.confidence,
            "country_check": m.country_check,
            "retailer_check": m.retailer_check,
            "ean_check": m.ean_check,
            "ean_status": m.ean_status,
            "ean_conflict_is_blocking": m.ean_conflict_is_blocking,
            "input_ean_valid": m.input_ean_valid,
            "input_ean_normalized": m.input_ean_normalized,
            "page_gtins_valid": "|".join(m.page_gtins_valid),
            "page_gtins_ignored": "|".join(m.page_gtins_ignored),
            "exact_product_check": m.exact_product_check,
            "variant_check": m.variant_check,
            "variant_conflict_terms": "|".join(m.variant_conflict_terms),
            "identity_driver": m.identity_driver,
            "selected_with_warning": m.selected_with_warning,
            "primary_reject_reason": m.primary_reject_reason,
            "title_check": m.title_check,
            "quantity_check": m.quantity_check,
            "page_type_check": m.page_type_check,
            "scrape_status_code": m.scrape_status_code,
            "scrape_word_count": m.scrape_word_count,
            "scrape_final_url": m.scrape_final_url,
            "richness_score": m.richness_score,
            "brand": m.brand,
            "manufacturer": m.manufacturer,
            "image_count": m.image_count,
            "specs_count": m.specs_count,
            "organic_calls_used": m.organic_calls_used,
            "ai_mode_calls_used": m.ai_mode_calls_used,
            "scrape_calls_used": m.scrape_calls_used,
            "termination_reason": m.termination_reason,
            "availability_inference": m.availability_inference,
            "match_reason": m.match_reason,
            "justification": m.justification,
        }

    def _summary_row(self, state: ProductSearchState) -> dict[str, Any]:
        final = state.final_result
        return {
            "row_id": state.task.row_id,
            "main_text": state.task.main_text,
            "country_code": state.task.country_code,
            "country_name": self.country_profiles.get(state.task.country_code).country_name,
            "language_code": state.task.language_code,
            "country_language_order": "|".join(lp.language_code for lp in self.country_profiles.language_profiles_for(state.task.country_code, state.task.language_code)),
            "ean": state.task.ean,
            "retailer_name": state.task.retailer_name,
            "resolution_status": final.resolution_status if final else "UNRESOLVED",
            "product_url": final.product_url if final else None,
            "validation_status": final.validation_status if final else None,
            "identity_status": final.identity_status if final else None,
            "exact_product_check": final.exact_product_check if final else "UNKNOWN",
            "variant_check": final.variant_check if final else "UNKNOWN",
            "ean_status": final.ean_status if final else "UNKNOWN",
            "candidate_count": len(state.candidates),
            "scorecard_count": len(state.scorecards),
            "scrape_count": len(state.scrapes),
            "scrapable_count": sum(1 for s in state.scrapes.values() if s.is_scrapable),
            "verified_count": sum(1 for c in state.scorecards if c.verification and c.verification.identity_status == "VERIFIED"),
            "country_candidate_count": sum(1 for c in state.scorecards if c.country_check == "MATCHED"),
            "organic_calls_used": state.budget.snapshot().organic_used,
            "ai_mode_calls_used": state.budget.snapshot().ai_mode_used,
            "scrape_calls_used": state.budget.snapshot().scrape_used,
            "termination_reason": state.termination_reason,
            "availability_inference": final.availability_inference if final else "UNKNOWN",
        }

    def _candidate_row(self, state: ProductSearchState, card: CandidateScorecard, rank: int) -> dict[str, Any]:
        c = card.candidate
        s = card.scrape
        v = card.verification
        final_url = state.final_result.product_url if state.final_result else None
        lang = self._candidate_language_info(state, c)
        country_specific = self.country_profiles.domain_matches_country(c.url, state.task.country_code)
        return {
            "rank": rank,
            "row_id": state.task.row_id,
            "selected_best": bool(final_url and c.url == final_url),
            "url": c.url,
            "domain": c.domain,
            "country_specific_candidate": country_specific,
            "language_code": lang.get("language_code"),
            "language_name": lang.get("language_name"),
            "language_priority": lang.get("language_priority"),
            "language_distribution_weight": lang.get("language_distribution_weight"),
            "title": c.title,
            "source_types": "|".join(c.source_types),
            "query_sources": "|".join(c.query_sources),
            "best_position": c.best_position,
            "organic_count": c.organic_count,
            "ai_reference_count": c.ai_reference_count,
            "ai_declared_final": c.ai_declared_final,
            "country_check": card.country_check,
            "retailer_check": card.retailer_check,
            "validation_status": card.validation_status,
            "identity_status": v.identity_status if v else "UNVERIFIED",
            "exact_product_check": v.exact_product_check if v else "UNKNOWN",
            "variant_check": v.variant_check if v else "UNKNOWN",
            "variant_conflict_terms": "|".join(v.variant_conflict_terms) if v else "",
            "identity_driver": v.identity_driver if v else "UNKNOWN",
            "selected_with_warning": card.selected_with_warning,
            "primary_reject_reason": card.primary_reject_reason,
            "confidence": card.final_confidence,
            "weighted_confidence": card.weighted_confidence,
            "confidence_cap": card.confidence_cap,
            "ean_score": card.ean_score,
            "title_score": card.title_score,
            "country_score": card.country_score,
            "scrape_score": card.scrape_score,
            "identity_score": card.identity_score,
            "richness_score": card.richness_score,
            "scraped": bool(s and s.scraped),
            "scrape_success": bool(s and s.success),
            "reachable": bool(s and s.reachable),
            "is_scrapable": bool(s and s.is_scrapable),
            "looks_like_product_page": bool(s and s.looks_like_product_page),
            "status_code": s.status_code if s else None,
            "word_count": s.word_count if s else 0,
            "markdown_chars": s.markdown_chars if s else 0,
            "ean_check": v.ean_check if v else "UNKNOWN",
            "ean_status": v.ean_status if v else "UNKNOWN",
            "ean_conflict_is_blocking": v.ean_conflict_is_blocking if v else False,
            "input_ean_valid": v.input_ean_valid if v else None,
            "input_ean_normalized": v.input_ean_normalized if v else None,
            "page_gtins_valid": "|".join(v.page_gtins_valid) if v else "",
            "page_gtins_ignored": "|".join(v.page_gtins_ignored) if v else "",
            "title_check": v.title_check if v else "UNKNOWN",
            "quantity_check": v.quantity_check if v else "UNKNOWN",
            "page_type_check": v.page_type_check if v else "UNKNOWN",
            "hard_failures": "; ".join(card.hard_failures),
            "soft_warnings": "; ".join(card.soft_warnings),
            "ranking_reasons": " | ".join(card.ranking_reasons),
        }

    def _scrape_row(self, url: str, s) -> dict[str, Any]:
        return {
            "url": url,
            "final_url": s.final_url,
            "scraped": s.scraped,
            "success": s.success,
            "reachable": s.reachable,
            "is_scrapable": s.is_scrapable,
            "status_code": s.status_code,
            "looks_like_product_page": s.looks_like_product_page,
            "looks_like_homepage": s.looks_like_homepage,
            "is_soft_404": s.is_soft_404,
            "title": s.title,
            "h1": s.h1,
            "page_product_name": s.page_product_name,
            "brand": s.brand,
            "manufacturer": s.manufacturer,
            "has_price": s.has_price,
            "currency": s.currency,
            "availability": s.availability,
            "structured_eans": "|".join(s.structured_eans),
            "word_count": s.word_count,
            "markdown_chars": s.markdown_chars,
            "image_count": s.image_count,
            "internal_link_count": s.internal_link_count,
            "external_link_count": s.external_link_count,
            "richness_score": s.richness_score,
            "error": s.error,
        }

    def _action_row(self, record) -> dict[str, Any]:
        return {
            "iteration": record.iteration,
            "action_type": record.action.action_type.value,
            "reason": record.action.reason,
            "scope": record.action.metadata.get("scope"),
            "kind": record.action.metadata.get("kind"),
            "language_code": record.action.metadata.get("language_code"),
            "language_name": record.action.metadata.get("language_name"),
            "language_priority": record.action.metadata.get("language_priority"),
            "language_distribution_weight": record.action.metadata.get("language_distribution_weight"),
            "query": record.action.query,
            "url": record.action.url,
            "success": record.success,
            "output_summary": json.dumps(record.output_summary, ensure_ascii=False, default=str),
            "error": record.error,
        }


    def _language_profile_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        profile = self.country_profiles.get(state.task.country_code)
        rows = profile.to_language_rows()
        for row in rows:
            row["active_requested_language"] = state.task.language_code
            row["search_order"] = "|".join(lp.language_code for lp in profile.language_profiles_for(state.task.language_code))
        return rows

    def _query_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        query_index = 0
        for record in state.actions_taken:
            if not record.action.query:
                continue
            query_index += 1
            rows.append({
                "query_index": query_index,
                "iteration": record.iteration,
                "action_type": record.action.action_type.value,
                "scope": record.action.metadata.get("scope"),
                "kind": record.action.metadata.get("kind"),
                "language_code": record.action.metadata.get("language_code"),
                "language_name": record.action.metadata.get("language_name"),
                "language_priority": record.action.metadata.get("language_priority"),
                "language_distribution_weight": record.action.metadata.get("language_distribution_weight"),
                "success": record.success,
                "query": record.action.query,
            })
        if not rows:
            return [{"query_index": None, "query": None}]
        return rows

    def _candidate_language_info(self, state: ProductSearchState, card_or_candidate) -> dict[str, Any]:
        candidate = getattr(card_or_candidate, "candidate", card_or_candidate)
        query_sources = set(getattr(candidate, "query_sources", ()) or ())
        for record in state.actions_taken:
            if record.action.action_type != ActionType.ORGANIC_SEARCH:
                continue
            if record.action.query and record.action.query in query_sources:
                return {
                    "language_code": record.action.metadata.get("language_code"),
                    "language_name": record.action.metadata.get("language_name"),
                    "language_priority": record.action.metadata.get("language_priority"),
                    "language_distribution_weight": record.action.metadata.get("language_distribution_weight"),
                }
        return {}

    def _selected_candidate_language(self, state: ProductSearchState) -> dict[str, Any]:
        final = state.final_result.product_url if state.final_result else None
        if not final:
            return {}
        for card in state.scorecards:
            if card.candidate.url == final:
                return self._candidate_language_info(state, card.candidate)
        return {}

    def _write_csv(self, path: Path, rows: Iterable[dict[str, Any]]) -> None:
        rows = list(rows)
        if not rows:
            path.write_text("", encoding="utf-8")
            return
        fieldnames: list[str] = []
        for row in rows:
            for key in row.keys():
                if key not in fieldnames:
                    fieldnames.append(key)
        with path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def _write_json(self, path: Path, obj: Any) -> None:
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    def _safe(self, value: str) -> str:
        return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value)[:120]
