from __future__ import annotations

from dataclasses import dataclass, field

from product_evidence_harness.config import HarnessConfig
from product_evidence_harness.constants import TERMINATION_BUDGET_EXHAUSTED, TERMINATION_VERIFIED
from product_evidence_harness.contracts import ActionType, AgentAction, ProductSearchState
from product_evidence_harness.country_profiles import CountryProfileRegistry
from product_evidence_harness.query_builder import QueryBuilder


@dataclass(frozen=True)
class HarnessPlanner:
    """Rule-based bounded planner for search/scrape feedback.

    The planner searches requested-country language markets in configured
    priority/distribution order. It only triggers global fallback after the
    country-language search budget has been exhausted or no country-specific
    candidates have become usable.
    """

    config: HarnessConfig
    query_builder: QueryBuilder
    country_profiles: CountryProfileRegistry = field(default_factory=CountryProfileRegistry.load)

    def next_action(self, state: ProductSearchState) -> AgentAction:
        best = state.best_scorecard()
        if (
            best
            and best.scrape
            and best.scrape.is_scrapable
            and best.verification
            and best.verification.identity_status == "VERIFIED"
            and best.verification.exact_product_check == "EXACT_MATCH"
            and best.verification.variant_check != "CONFLICT"
            and not best.hard_failures
        ):
            return AgentAction(ActionType.FINISH, TERMINATION_VERIFIED)

        # Scrape country-specific candidates as soon as they are discovered.
        next_country_url = self._next_unscraped_url(state, country_specific=True)
        if next_country_url and self.config.scrape_enabled and state.budget.can_scrape():
            return AgentAction(
                ActionType.SCRAPE_URL,
                "scrape highest-priority country-specific candidate",
                url=next_country_url,
                metadata={"scope": "country"},
            )

        # If we scraped a near-match/sibling but exact product identity failed
        # while an EAN was provided, run one exact-EAN repair query before
        # broader language/AI/global fallback. This catches cases like same
        # retailer family page but wrong variant/form.
        if state.task.ean and state.budget.can_search_organic() and self._needs_exact_ean_repair(state):
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "exact EAN repair search after near-match or variant conflict",
                query=self.query_builder.exact_ean_repair_from_state(state),
                metadata={"kind": "exact_ean_repair", "scope": "country"},
            )

        # Search each country-internal language market in priority order. For CH
        # this means de -> fr -> it -> rm -> en, subject to organic budget.
        next_language_index = self._next_country_language_index(state)
        if next_language_index is not None and state.budget.can_search_organic():
            metadata = self.query_builder.country_language_metadata(state.task, next_language_index)
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "country-language product search",
                query=self.query_builder.country_language_search(state.task, language_index=next_language_index),
                metadata=metadata,
            )

        # Use AI Mode as a candidate discovery/repair step before conceding to a
        # global fallback. Any AI URL must still be scraped/verified before final.
        if state.candidates and state.budget.can_search_ai() and not self._ai_validation_done(state):
            prompt = self.query_builder.ai_validation_prompt(
                state.task,
                state.candidates[: self.config.max_candidates_for_ai],
                allow_global_fallback=self.config.policy.allow_global_fallback,
            )
            return AgentAction(ActionType.AI_MODE_SEARCH, "AI Mode validation/repair over candidate pool", query=prompt, metadata={"scope": "country_or_global", "kind": "ai_validation"})

        if not state.candidates and state.budget.can_search_ai() and not self._ai_discovery_done(state):
            prompt = self.query_builder.ai_discovery_prompt(
                state.task,
                allow_global_fallback=self.config.policy.allow_global_fallback,
            )
            return AgentAction(ActionType.AI_MODE_SEARCH, "AI Mode URL discovery because organic search produced no candidates", query=prompt, metadata={"scope": "country_or_global", "kind": "ai_discovery"})

        # If country-language search and AI repair do not resolve a usable URL,
        # allow one global organic fallback. Global results can be candidates but
        # the selector still requires scrapable same-product evidence.
        if self.config.policy.allow_global_fallback and state.budget.can_search_organic() and not self._global_search_done(state):
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "global fallback search after country-language searches did not resolve a final URL",
                query=self.query_builder.global_fallback(state.task),
                metadata={"kind": "global_fallback", "scope": "global"},
            )

        # Scrape global candidates only after country candidates and language
        # searches have been exhausted.
        next_global_url = self._next_unscraped_url(state, country_specific=False)
        if next_global_url and self.config.scrape_enabled and state.budget.can_scrape():
            return AgentAction(
                ActionType.SCRAPE_URL,
                "scrape global/alternative candidate after country-specific options are exhausted",
                url=next_global_url,
                metadata={"scope": "global_or_alternative"},
            )

        # Last repair search from scraped clues if organic budget remains.
        if state.budget.can_search_organic():
            global_fallback = self.config.policy.allow_global_fallback and self._global_search_done(state)
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "repair search generated from scrape evidence",
                query=self.query_builder.repair_from_state(state, global_fallback=global_fallback),
                metadata={"kind": "repair", "scope": "global" if global_fallback else "country"},
            )

        if state.budget.exhausted():
            return AgentAction(ActionType.FINISH, TERMINATION_BUDGET_EXHAUSTED)
        return AgentAction(ActionType.FINISH, "no_more_actions")

    def _needs_exact_ean_repair(self, state: ProductSearchState) -> bool:
        already_done = any(
            record.action.action_type == ActionType.ORGANIC_SEARCH
            and record.action.metadata.get("kind") == "exact_ean_repair"
            for record in state.actions_taken
        )
        if already_done:
            return False
        for card in state.scorecards:
            v = card.verification
            if not v:
                continue
            if v.ean_check == "CONFLICT" or v.variant_check == "CONFLICT" or v.exact_product_check == "MISMATCH":
                if self.country_profiles.domain_matches_country(card.candidate.url, state.task.country_code):
                    return True
        return False

    def _has_country_candidates(self, state: ProductSearchState) -> bool:
        return any(self.country_profiles.domain_matches_country(c.url, state.task.country_code) for c in state.candidates)

    def _next_unscraped_url(self, state: ProductSearchState, *, country_specific: bool) -> str | None:
        scraped = set(state.scrapes)
        ranked = [card.candidate for card in state.scorecards] or state.candidates
        for candidate in ranked:
            if candidate.url in scraped:
                continue
            is_country = self.country_profiles.domain_matches_country(candidate.url, state.task.country_code)
            if country_specific and is_country:
                return candidate.url
            if not country_specific and not is_country:
                return candidate.url
        return None

    def _next_country_language_index(self, state: ProductSearchState) -> int | None:
        done = {
            int(record.action.metadata.get("language_index"))
            for record in state.actions_taken
            if record.action.action_type == ActionType.ORGANIC_SEARCH
            and record.action.metadata.get("kind") == "country_language"
            and record.success
            and record.action.metadata.get("language_index") is not None
        }
        total = self.query_builder.country_language_count(state.task)
        # Do not let language-market searches consume the entire organic budget;
        # keep room for one global/repair search when configured.
        reserve_for_fallback = 1 if self.config.policy.allow_global_fallback else 0
        max_language_searches = max(1, self.config.budget.max_organic_searches - reserve_for_fallback)
        max_index = min(total, max_language_searches)
        for idx in range(max_index):
            if idx not in done:
                return idx
        return None

    def _global_search_done(self, state: ProductSearchState) -> bool:
        return any(
            record.action.action_type == ActionType.ORGANIC_SEARCH and record.action.metadata.get("kind") == "global_fallback"
            for record in state.actions_taken
        )

    def _ai_validation_done(self, state: ProductSearchState) -> bool:
        return any(
            record.action.action_type == ActionType.AI_MODE_SEARCH and record.action.metadata.get("kind") == "ai_validation"
            for record in state.actions_taken
        )

    def _ai_discovery_done(self, state: ProductSearchState) -> bool:
        return any(
            record.action.action_type == ActionType.AI_MODE_SEARCH and record.action.metadata.get("kind") == "ai_discovery"
            for record in state.actions_taken
        )
