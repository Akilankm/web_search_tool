from __future__ import annotations

from dataclasses import dataclass

from product_evidence_harness.config import HarnessConfig
from product_evidence_harness.constants import TERMINATION_BUDGET_EXHAUSTED, TERMINATION_VERIFIED
from product_evidence_harness.contracts import ActionType, AgentAction, LLMSearchQuery, ProductSearchState
from product_evidence_harness.country_profiles import CountryProfileRegistry
from product_evidence_harness.query_builder import QueryBuilder


@dataclass(frozen=True)
class HarnessPlanner:
    """LLM-controlled iterative discovery planner.

    The planner is deliberately not a linear pipeline.  After the initial
    product-identity/search plan, every iteration chooses the next best action
    from the current state:

        search -> candidate pool -> scrape -> score -> LLM judge -> repair -> search again

    The feedback edge is the important part: weak/non-scrapable/wrong-variant
    evidence changes the next query/fallback decision inside the same bounded
    run.  SerpAPI and crawl4ai remain tools; the LLM plans, diagnoses, and
    adjudicates within a strict per-product budget.
    """

    config: HarnessConfig
    query_builder: QueryBuilder
    country_profiles: CountryProfileRegistry

    def next_action(self, state: ProductSearchState) -> AgentAction:
        best = state.best_scorecard()
        if best and self._is_verified_usable(best):
            return AgentAction(ActionType.FINISH, TERMINATION_VERIFIED)

        # 0) LLM creates the product-identity/search campaign before any search.
        if self.config.enable_llm_search_planning and not self._llm_stage_done(state, "initial_search_plan"):
            if self._llm_calls_remaining(state) > self._reserved_llm_calls(state):
                return AgentAction(
                    ActionType.LLM_SEARCH_PLAN,
                    "LLM creates product-identity graph and country-first/global-fallback campaign",
                    metadata={"kind": "llm_search_plan", "loop_phase": "plan"},
                )

        # 1) If a prior diagnosis generated repair/global queries, execute them before
        #    scraping stale lower-quality candidates from an earlier search round.
        repair_query = self._next_planned_query(state, include_global=True, preferred_sources={"llm_search_feedback", "deterministic_feedback_fallback"})
        if repair_query and state.budget.can_search_organic():
            return self._organic_from_plan(repair_query, loop_phase="repair_search")

        # 2) Scrape the current best unscripted candidate.  This comes before
        #    draining all planned queries, making the process a real loop rather than
        #    search-batch -> scrape-batch -> judge.
        next_country_url = self._next_unscraped_url(state, country_specific=True)
        if next_country_url and state.budget.can_scrape():
            return AgentAction(
                ActionType.SCRAPE_URL,
                "scrape best country candidate so evidence can drive the next action",
                url=next_country_url,
                metadata={"scope": "country", "loop_phase": "scrape"},
            )

        # 3) Judge scraped promising candidates before continuing.  A rejection or
        #    insufficient-evidence judgement can trigger feedback/repair while budget remains.
        if self._should_adjudicate_now(state):
            return AgentAction(
                ActionType.LLM_EXACT_ADJUDICATION,
                "LLM judges scraped evidence inside the loop before deciding repair/fallback",
                metadata={"kind": "llm_exact_adjudication", "loop_phase": "judge"},
            )

        # 4) If evidence shows weakness or LLM rejected/flagged ambiguity, ask the
        #    LLM to repair the search.  Keep at least one call available for a later
        #    exact-product judgement unless one has already happened and no exact remains possible.
        if self._should_request_llm_feedback(state):
            return AgentAction(
                ActionType.LLM_SEARCH_FEEDBACK,
                "LLM diagnoses failed evidence and creates repair/fallback queries",
                metadata={"kind": "llm_search_feedback", "loop_phase": "diagnose_repair"},
            )

        # 5) Execute the next country-scoped planned query if we still need more candidates.
        planned_country = self._next_planned_query(state, include_global=False)
        if planned_country and state.budget.can_search_organic():
            return self._organic_from_plan(planned_country, loop_phase="country_search")

        # 6) Deterministic country-language fallback when LLM planning is disabled or failed.
        if not self.config.enable_llm_search_planning:
            idx = self._next_country_language_index(state)
            if idx is not None and state.budget.can_search_organic():
                meta = self.query_builder.country_language_metadata(state.task, idx)
                meta["loop_phase"] = "country_search"
                return AgentAction(
                    ActionType.ORGANIC_SEARCH,
                    "country/language-priority search",
                    query=self.query_builder.country_language_search(state.task, language_index=idx),
                    metadata=meta,
                )

        # 7) AI Mode is an addon discovery tool. Use it when organic/scrape evidence is weak,
        #    not as the primary brain.
        if (
            self.config.budget.max_ai_mode_searches > 0
            and state.budget.can_search_ai()
            and not self._ai_discovery_done(state)
            and self._should_use_ai_discovery(state)
        ):
            return AgentAction(
                ActionType.AI_MODE_SEARCH,
                "SerpAPI AI Mode addon discovery after weak organic evidence",
                query=self.query_builder.ai_discovery_prompt(state.task, allow_global_fallback=self.config.policy.allow_global_fallback),
                metadata={"kind": "ai_discovery", "scope": "country", "loop_phase": "addon_discovery"},
            )

        # 8) Scrape non-country/global candidates only after country candidates and repair
        #    attempts have not produced a verified exact URL.
        next_global_url = self._next_unscraped_url(state, country_specific=False)
        if next_global_url and state.budget.can_scrape():
            return AgentAction(
                ActionType.SCRAPE_URL,
                "scrape global/alternative candidate after country evidence failed",
                url=next_global_url,
                metadata={"scope": "global_or_alternative", "loop_phase": "scrape_global"},
            )

        # 9) Execute queued global fallback planned by LLM.
        planned_global = self._next_planned_query(state, include_global=True, only_global=True)
        if planned_global and state.budget.can_search_organic():
            return self._organic_from_plan(planned_global, loop_phase="global_fallback_search")

        # 10) Last deterministic global fallback when LLM budget/queries are exhausted.
        if state.budget.can_search_organic() and not self._global_search_done(state):
            return AgentAction(
                ActionType.ORGANIC_SEARCH,
                "deterministic global fallback search after country loop exhausted",
                query=self.query_builder.global_fallback(state.task),
                metadata={"kind": "global_fallback", "scope": "global", "language_code": self.config.global_fallback_language_code, "loop_phase": "global_fallback_search"},
            )

        if state.budget.exhausted():
            return AgentAction(ActionType.FINISH, TERMINATION_BUDGET_EXHAUSTED)
        return AgentAction(ActionType.FINISH, "no_more_actions")

    def _organic_from_plan(self, planned: LLMSearchQuery, *, loop_phase: str) -> AgentAction:
        return AgentAction(
            ActionType.ORGANIC_SEARCH,
            planned.reason or "execute planned query",
            query=planned.query,
            metadata={
                "kind": planned.source,
                "scope": planned.scope,
                "reason": planned.reason,
                "priority": planned.priority,
                "language_code": planned.language_code,
                "language_name": planned.language_name,
                "must_include_ean": planned.must_include_ean,
                "loop_phase": loop_phase,
            },
        )

    def _is_verified_usable(self, card) -> bool:
        s = card.scrape
        v = card.verification
        if not s or not v:
            return False
        if not (s.scraped and s.success and s.reachable and s.is_scrapable and s.looks_like_product_page):
            return False
        if card.hard_failures:
            return False
        if self.config.policy.require_llm_exact_match_for_final or self.config.llm_require_exact_match_for_final:
            return card.llm_decision in {"EXACT_MATCH", "EXACT_MATCH_WITH_WARNING"} and card.llm_exact_product_match
        return (
            v.identity_status == "VERIFIED"
            and v.exact_product_check in {"EXACT_MATCH", "UNKNOWN"}
            and v.variant_check != "CONFLICT"
        )

    def _llm_calls_remaining(self, state: ProductSearchState) -> int:
        return max(0, self.config.llm_max_calls_per_product - len(state.llm_call_records))

    def _reserved_llm_calls(self, state: ProductSearchState) -> int:
        if not self.config.reserve_llm_call_for_adjudication or not self.config.enable_llm_adjudication:
            return 0
        # Reserve one adjudication call until an exact-product judgement has accepted
        # a final candidate. A rejected/insufficient judgement should still leave
        # budget for a later repaired candidate to be judged.
        return 0 if any(j.accepted_for_final for j in state.llm_judgements.values()) else 1

    def _llm_stage_done(self, state: ProductSearchState, stage: str) -> bool:
        return any(p.stage == stage for p in state.llm_search_plans)

    def _next_planned_query(
        self,
        state: ProductSearchState,
        *,
        include_global: bool = False,
        only_global: bool = False,
        preferred_sources: set[str] | None = None,
    ) -> LLMSearchQuery | None:
        executed = set(state.queries)
        in_progress = {
            r.action.query for r in state.actions_taken
            if r.action.action_type == ActionType.ORGANIC_SEARCH and r.action.query
        }
        for query in sorted(state.planned_search_queries, key=lambda q: (q.priority, q.source, q.query)):
            if query.query in executed or query.query in in_progress:
                continue
            scope = str(query.scope).lower()
            if only_global and scope != "global":
                continue
            if not include_global and scope == "global":
                continue
            if preferred_sources and query.source not in preferred_sources:
                continue
            return query
        return None

    def _should_adjudicate_now(self, state: ProductSearchState) -> bool:
        if not self.config.enable_llm_adjudication or self._llm_calls_remaining(state) <= 0:
            return False
        if not state.scorecards:
            return False
        for card in state.scorecards[: max(1, self.config.llm_adjudicate_top_k)]:
            s = card.scrape
            if not s or not (s.scraped and s.success and s.reachable and s.is_scrapable and s.looks_like_product_page):
                continue
            if card.llm_used or card.candidate.url in state.llm_judgements:
                continue
            # Exact/probable candidates, ambiguous variants, and rich weak candidates all deserve
            # a judgement because the judgement can steer repair inside the loop.
            if card.validation_status == "VERIFIED" or not card.hard_failures or card.title_score >= 0.45 or card.richness_score >= 0.45:
                return True
        return False

    def _should_request_llm_feedback(self, state: ProductSearchState) -> bool:
        if not self.config.enable_llm_search_feedback:
            return False
        if self._llm_feedback_count(state) >= self.config.llm_search_feedback_max_rounds:
            return False
        if self._next_planned_query(state, include_global=True, preferred_sources={"llm_search_feedback", "deterministic_feedback_fallback"}):
            return False
        # Keep at least one call for later adjudication unless at least one judgement already exists.
        if self._llm_calls_remaining(state) <= self._reserved_llm_calls(state):
            return False
        if not state.candidates and state.budget.organic_used >= 1:
            return True
        if not state.scrapes:
            return False

        # If any LLM judgement already accepted an exact candidate, no repair is needed.
        if any(j.accepted_for_final for j in state.llm_judgements.values()):
            return False

        # Ask for repair after explicit LLM rejection/insufficient evidence.
        if state.llm_judgements and any(j.decision in {"SIBLING_VARIANT", "WRONG_PRODUCT", "INSUFFICIENT_EVIDENCE", "NON_PRODUCT_PAGE", "UNSCRAPABLE", "LLM_FAILED"} for j in state.llm_judgements.values()):
            return True

        # Ask for repair when all scraped top candidates are unusable, hard-conflicted,
        # weak, not product pages, or non-scrapable.
        top = state.scorecards[:5]
        if top and all(self._card_is_loop_failure(c) for c in top if c.scrape):
            return True
        return False

    def _card_is_loop_failure(self, card) -> bool:
        s = card.scrape
        if not s:
            return False
        if not (s.scraped and s.success and s.reachable and s.is_scrapable and s.looks_like_product_page):
            return True
        if card.hard_failures:
            return True
        if card.validation_status != "VERIFIED":
            return True
        if (self.config.policy.require_llm_exact_match_for_final or self.config.llm_require_exact_match_for_final or self.config.enable_llm_adjudication):
            return not (card.llm_decision in {"EXACT_MATCH", "EXACT_MATCH_WITH_WARNING"} and card.llm_exact_product_match)
        return False

    def _should_use_ai_discovery(self, state: ProductSearchState) -> bool:
        if not state.candidates:
            return True
        if not state.scrapes:
            return False
        top = state.scorecards[:5]
        if not top:
            return False
        return all((not c.scrape) or (not c.scrape.is_scrapable) or c.hard_failures or c.validation_status != "VERIFIED" for c in top)

    def _llm_feedback_count(self, state: ProductSearchState) -> int:
        return sum(1 for p in state.llm_search_plans if p.stage == "search_feedback")

    def _next_unscraped_url(self, state: ProductSearchState, *, country_specific: bool) -> str | None:
        scraped = set(state.scrapes)
        ranked = [card.candidate for card in state.scorecards] or state.candidates
        for candidate in ranked:
            if candidate.url in scraped:
                continue
            is_country = self.country_profiles.domain_matches_country(candidate.url, state.task.country_code)
            if country_specific and is_country:
                return candidate.url
            if not country_specific and not is_country:
                return candidate.url
        return None

    def _next_country_language_index(self, state: ProductSearchState) -> int | None:
        done = {
            int(record.action.metadata.get("language_index"))
            for record in state.actions_taken
            if record.action.action_type == ActionType.ORGANIC_SEARCH
            and record.action.metadata.get("kind") == "country_language"
            and record.action.metadata.get("language_index") is not None
        }
        total = self.query_builder.country_language_count(state.task)
        reserve_for_fallback = 1 if self.config.policy.allow_global_fallback else 0
        max_language_searches = max(1, self.config.budget.max_organic_searches - reserve_for_fallback)
        for idx in range(min(total, max_language_searches)):
            if idx not in done:
                return idx
        return None

    def _global_search_done(self, state: ProductSearchState) -> bool:
        return any(
            r.action.action_type == ActionType.ORGANIC_SEARCH
            and r.action.metadata.get("scope") == "global"
            for r in state.actions_taken
        )

    def _ai_discovery_done(self, state: ProductSearchState) -> bool:
        return any(r.action.action_type == ActionType.AI_MODE_SEARCH and r.action.metadata.get("kind") == "ai_discovery" for r in state.actions_taken)
