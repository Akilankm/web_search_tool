from __future__ import annotations

import csv
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Iterable

from product_evidence_harness.contracts import ActionType, CandidateScorecard, ProductSearchState
from product_evidence_harness.country_profiles import CountryProfileRegistry


@dataclass(frozen=True)
class ArtifactWriter:
    """Compact analytics-friendly per-row output writer.

    The default output is intentionally CSV-first and small. It writes enough
    information to understand why the best URL was selected or why no final URL
    was resolved, without dumping large markdown/page text.
    """

    root_dir: str | Path
    include_debug_json: bool = False
    country_profiles: CountryProfileRegistry = field(default_factory=CountryProfileRegistry.load)

    def write_state(self, state: ProductSearchState) -> Path:
        product_dir = Path(self.root_dir) / self._safe(state.task.row_id)
        product_dir.mkdir(parents=True, exist_ok=True)

        self._write_csv(product_dir / "best_url.csv", [self._best_row(state)])
        self._write_csv(product_dir / "summary.csv", [self._summary_row(state)])
        self._write_csv(product_dir / "candidates.csv", [self._candidate_row(state, c, idx) for idx, c in enumerate(state.scorecards, start=1)])
        self._write_csv(product_dir / "scrapes.csv", [self._scrape_row(url, s) for url, s in state.scrapes.items()])
        self._write_csv(product_dir / "actions.csv", [self._action_row(a) for a in state.actions_taken])
        self._write_csv(product_dir / "queries.csv", self._query_rows(state))
        self._write_csv(product_dir / "search_plan.csv", self._search_plan_rows(state, stage="initial_search_plan"))
        self._write_csv(product_dir / "search_feedback.csv", self._search_plan_rows(state, stage="search_feedback"))
        self._write_csv(product_dir / "language_profile.csv", self._language_profile_rows(state))
        self._write_csv(product_dir / "llm_judgements.csv", self._llm_judgement_rows(state))
        self._write_csv(product_dir / "llm_calls.csv", self._llm_call_rows(state))
        self._write_csv(product_dir / "detector_findings.csv", self._detector_finding_rows(state))
        self._write_csv(product_dir / "evidence_scorecards.csv", self._evidence_scorecard_rows(state))
        self._write_csv(product_dir / "identity_graph.csv", [self._identity_graph_row(state)])
        self._write_json(product_dir / "run_summary.json", self._run_summary(state))

        if self.include_debug_json:
            self._write_json(product_dir / "debug_state.json", state.to_dict())
        return product_dir

    def _best_row(self, state: ProductSearchState) -> dict[str, Any]:
        m = state.final_result
        if not m:
            return {"row_id": state.task.row_id, "resolution_status": "UNRESOLVED", "product_url": None}
        selected_language = self._selected_candidate_language(state)
        return {
            "row_id": m.row_id,
            "main_text": m.main_text,
            "country_code": m.country_code,
            "ean": m.ean,
            "retailer_name": m.retailer_name,
            "selected_language_code": selected_language.get("language_code"),
            "selected_language_name": selected_language.get("language_name"),
            "selected_language_priority": selected_language.get("language_priority"),
            "selected_language_distribution_weight": selected_language.get("language_distribution_weight"),
            "product_url": m.product_url,
            "best_available_url": m.best_available_url,
            "verified_exact_url": m.verified_exact_url,
            "best_reference_url": m.best_reference_url,
            "reference_url_status": m.reference_url_status,
            "url_decision_status": m.url_decision_status,
            "input_validation_status": m.input_validation_status,
            "input_validation_warnings": "|".join(m.input_validation_warnings),
            "is_country_specific": m.is_country_specific,
            "is_global_fallback": m.is_global_fallback,
            "needs_review": m.needs_review,
            "resolution_status": m.resolution_status,
            "validation_status": m.validation_status,
            "identity_status": m.identity_status,
            "is_exact_product_match": m.is_exact_product_match,
            "is_scrapable": m.is_scrapable,
            "confidence": m.confidence,
            "country_check": m.country_check,
            "retailer_check": m.retailer_check,
            "ean_check": m.ean_check,
            "ean_status": m.ean_status,
            "ean_conflict_is_blocking": m.ean_conflict_is_blocking,
            "input_ean_valid": m.input_ean_valid,
            "input_ean_normalized": m.input_ean_normalized,
            "page_gtins_valid": "|".join(m.page_gtins_valid),
            "page_gtins_ignored": "|".join(m.page_gtins_ignored),
            "exact_product_check": m.exact_product_check,
            "variant_check": m.variant_check,
            "variant_conflict_terms": "|".join(m.variant_conflict_terms),
            "identity_driver": m.identity_driver,
            "selected_with_warning": m.selected_with_warning,
            "primary_reject_reason": m.primary_reject_reason,
            "llm_used": m.llm_used,
            "llm_decision": m.llm_decision,
            "llm_confidence": m.llm_confidence,
            "llm_exact_product_match": m.llm_exact_product_match,
            "llm_reject_reason": m.llm_reject_reason,
            "llm_justification": m.llm_justification,
            "llm_calls_used": m.llm_calls_used,
            "title_check": m.title_check,
            "quantity_check": m.quantity_check,
            "page_type_check": m.page_type_check,
            "scrape_status_code": m.scrape_status_code,
            "scrape_word_count": m.scrape_word_count,
            "scrape_final_url": m.scrape_final_url,
            "richness_score": m.richness_score,
            "brand": m.brand,
            "manufacturer": m.manufacturer,
            "image_count": m.image_count,
            "specs_count": m.specs_count,
            "organic_calls_used": m.organic_calls_used,
            "ai_mode_calls_used": m.ai_mode_calls_used,
            "scrape_calls_used": m.scrape_calls_used,
            "termination_reason": m.termination_reason,
            "availability_inference": m.availability_inference,
            "match_reason": m.match_reason,
            "justification": m.justification,
        }

    def _summary_row(self, state: ProductSearchState) -> dict[str, Any]:
        final = state.final_result
        return {
            "row_id": state.task.row_id,
            "main_text": state.task.main_text,
            "country_code": state.task.country_code,
            "country_name": self.country_profiles.get(state.task.country_code).country_name,
            "language_code": state.task.language_code,
            "country_language_order": "|".join(lp.language_code for lp in self.country_profiles.language_profiles_for(state.task.country_code, state.task.language_code)),
            "ean": state.task.ean,
            "retailer_name": state.task.retailer_name,
            "resolution_status": final.resolution_status if final else "UNRESOLVED",
            "url_decision_status": final.url_decision_status if final else "UNRESOLVED",
            "product_url": final.product_url if final else None,
            "best_available_url": final.best_available_url if final else None,
            "verified_exact_url": final.verified_exact_url if final else None,
            "best_reference_url": final.best_reference_url if final else None,
            "reference_url_status": final.reference_url_status if final else "",
            "validation_status": final.validation_status if final else None,
            "identity_status": final.identity_status if final else None,
            "exact_product_check": final.exact_product_check if final else "UNKNOWN",
            "variant_check": final.variant_check if final else "UNKNOWN",
            "ean_status": final.ean_status if final else "UNKNOWN",
            "candidate_count": len(state.candidates),
            "scorecard_count": len(state.scorecards),
            "scrape_count": len(state.scrapes),
            "scrapable_count": sum(1 for s in state.scrapes.values() if s.is_scrapable),
            "verified_count": sum(1 for c in state.scorecards if c.verification and c.verification.identity_status == "VERIFIED"),
            "country_candidate_count": sum(1 for c in state.scorecards if c.country_check == "MATCHED"),
            "organic_calls_used": state.budget.snapshot().organic_used,
            "ai_mode_calls_used": state.budget.snapshot().ai_mode_used,
            "scrape_calls_used": state.budget.snapshot().scrape_used,
            "llm_calls_used": len(state.llm_call_records),
            "llm_judgement_count": len(state.llm_judgements),
            "termination_reason": state.termination_reason,
            "availability_inference": final.availability_inference if final else "UNKNOWN",
        }

    def _candidate_row(self, state: ProductSearchState, card: CandidateScorecard, rank: int) -> dict[str, Any]:
        c = card.candidate
        s = card.scrape
        v = card.verification
        final_url = state.final_result.product_url if state.final_result else None
        lang = self._candidate_language_info(state, c)
        country_specific = self.country_profiles.domain_matches_country(c.url, state.task.country_code)
        return {
            "rank": rank,
            "row_id": state.task.row_id,
            "selected_best": bool(final_url and c.url == final_url),
            "url": c.url,
            "domain": c.domain,
            "country_specific_candidate": country_specific,
            "language_code": lang.get("language_code"),
            "language_name": lang.get("language_name"),
            "language_priority": lang.get("language_priority"),
            "language_distribution_weight": lang.get("language_distribution_weight"),
            "title": c.title,
            "source_types": "|".join(c.source_types),
            "query_sources": "|".join(c.query_sources),
            "best_position": c.best_position,
            "organic_count": c.organic_count,
            "ai_reference_count": c.ai_reference_count,
            "ai_declared_final": c.ai_declared_final,
            "country_check": card.country_check,
            "retailer_check": card.retailer_check,
            "validation_status": card.validation_status,
            "identity_status": v.identity_status if v else "UNVERIFIED",
            "exact_product_check": v.exact_product_check if v else "UNKNOWN",
            "variant_check": v.variant_check if v else "UNKNOWN",
            "variant_conflict_terms": "|".join(v.variant_conflict_terms) if v else "",
            "detector_findings_count": len(v.detector_findings) if v else 0,
            "detector_hard_conflicts": "|".join(f.get("explanation", "") for f in (v.detector_findings if v else ()) if f.get("status") == "CONFLICT" and f.get("severity") == "HARD_BLOCKER"),
            "identity_driver": v.identity_driver if v else "UNKNOWN",
            "selected_with_warning": card.selected_with_warning,
            "primary_reject_reason": card.primary_reject_reason,
            "llm_used": card.llm_used,
            "llm_decision": card.llm_decision,
            "llm_confidence": card.llm_confidence,
            "llm_exact_product_match": card.llm_exact_product_match,
            "llm_reject_reason": card.llm_reject_reason,
            "llm_justification": card.llm_justification,
            "confidence": card.final_confidence,
            "weighted_confidence": card.weighted_confidence,
            "confidence_cap": card.confidence_cap,
            "ean_score": card.ean_score,
            "title_score": card.title_score,
            "country_score": card.country_score,
            "scrape_score": card.scrape_score,
            "identity_score": card.identity_score,
            "richness_score": card.richness_score,
            "scraped": bool(s and s.scraped),
            "scrape_success": bool(s and s.success),
            "reachable": bool(s and s.reachable),
            "is_scrapable": bool(s and s.is_scrapable),
            "looks_like_product_page": bool(s and s.looks_like_product_page),
            "status_code": s.status_code if s else None,
            "word_count": s.word_count if s else 0,
            "markdown_chars": s.markdown_chars if s else 0,
            "ean_check": v.ean_check if v else "UNKNOWN",
            "ean_status": v.ean_status if v else "UNKNOWN",
            "ean_conflict_is_blocking": v.ean_conflict_is_blocking if v else False,
            "input_ean_valid": v.input_ean_valid if v else None,
            "input_ean_normalized": v.input_ean_normalized if v else None,
            "page_gtins_valid": "|".join(v.page_gtins_valid) if v else "",
            "page_gtins_ignored": "|".join(v.page_gtins_ignored) if v else "",
            "title_check": v.title_check if v else "UNKNOWN",
            "quantity_check": v.quantity_check if v else "UNKNOWN",
            "page_type_check": v.page_type_check if v else "UNKNOWN",
            "hard_failures": "; ".join(card.hard_failures),
            "soft_warnings": "; ".join(card.soft_warnings),
            "ranking_reasons": " | ".join(card.ranking_reasons),
        }

    def _scrape_row(self, url: str, s) -> dict[str, Any]:
        return {
            "url": url,
            "final_url": s.final_url,
            "scraped": s.scraped,
            "success": s.success,
            "reachable": s.reachable,
            "is_scrapable": s.is_scrapable,
            "status_code": s.status_code,
            "looks_like_product_page": s.looks_like_product_page,
            "looks_like_homepage": s.looks_like_homepage,
            "is_soft_404": s.is_soft_404,
            "title": s.title,
            "h1": s.h1,
            "page_product_name": s.page_product_name,
            "brand": s.brand,
            "manufacturer": s.manufacturer,
            "has_price": s.has_price,
            "currency": s.currency,
            "availability": s.availability,
            "structured_eans": "|".join(s.structured_eans),
            "gtin_evidence_json": (s.attributes or {}).get("gtin_evidence_json", ""),
            "word_count": s.word_count,
            "markdown_chars": s.markdown_chars,
            "image_count": s.image_count,
            "internal_link_count": s.internal_link_count,
            "external_link_count": s.external_link_count,
            "richness_score": s.richness_score,
            "error": s.error,
        }

    def _action_row(self, record) -> dict[str, Any]:
        return {
            "iteration": record.iteration,
            "action_type": record.action.action_type.value,
            "reason": record.action.reason,
            "scope": record.action.metadata.get("scope"),
            "kind": record.action.metadata.get("kind"),
            "language_code": record.action.metadata.get("language_code"),
            "language_name": record.action.metadata.get("language_name"),
            "language_priority": record.action.metadata.get("language_priority"),
            "language_distribution_weight": record.action.metadata.get("language_distribution_weight"),
            "query": record.action.query,
            "url": record.action.url,
            "success": record.success,
            "output_summary": json.dumps(record.output_summary, ensure_ascii=False, default=str),
            "error": record.error,
        }


    def _language_profile_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        profile = self.country_profiles.get(state.task.country_code)
        rows = profile.to_language_rows()
        for row in rows:
            row["active_requested_language"] = state.task.language_code
            row["search_order"] = "|".join(lp.language_code for lp in profile.language_profiles_for(state.task.language_code))
        return rows

    def _search_plan_rows(self, state: ProductSearchState, *, stage: str) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for plan in state.llm_search_plans:
            if plan.stage != stage:
                continue
            if not plan.queries:
                rows.append({
                    "row_id": plan.row_id,
                    "llm_call_index": plan.call_index,
                    "stage": plan.stage,
                    "success": plan.success,
                    "expanded_main_text": plan.expanded_main_text,
                    "critical_terms": "|".join(plan.critical_terms),
                    "variant_terms_to_preserve": "|".join(plan.variant_terms_to_preserve),
                    "negative_terms": "|".join(plan.negative_terms),
                    "query": None,
                    "reasoning": plan.reasoning,
                    "error": plan.error,
                })
            for idx, q in enumerate(plan.queries, start=1):
                rows.append({
                    "row_id": plan.row_id,
                    "llm_call_index": plan.call_index,
                    "stage": plan.stage,
                    "success": plan.success,
                    "query_index": idx,
                    "query": q.query,
                    "query_source": q.source,
                    "scope": q.scope,
                    "reason": q.reason,
                    "priority": q.priority,
                    "must_include_ean": q.must_include_ean,
                    "expanded_main_text": plan.expanded_main_text,
                    "critical_terms": "|".join(plan.critical_terms),
                    "variant_terms_to_preserve": "|".join(plan.variant_terms_to_preserve),
                    "negative_terms": "|".join(plan.negative_terms),
                    "reasoning": plan.reasoning,
                    "error": plan.error,
                })
        if not rows:
            return [{"row_id": state.task.row_id, "stage": stage, "note": "no LLM search plan/feedback recorded"}]
        return rows

    def _query_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        query_index = 0
        for record in state.actions_taken:
            if not record.action.query:
                continue
            query_index += 1
            rows.append({
                "query_index": query_index,
                "iteration": record.iteration,
                "action_type": record.action.action_type.value,
                "scope": record.action.metadata.get("scope"),
                "kind": record.action.metadata.get("kind"),
                "loop_phase": record.action.metadata.get("loop_phase"),
                "repair_reason": record.action.metadata.get("reason"),
                "language_code": record.action.metadata.get("language_code"),
                "language_name": record.action.metadata.get("language_name"),
                "language_priority": record.action.metadata.get("language_priority"),
                "language_distribution_weight": record.action.metadata.get("language_distribution_weight"),
                "success": record.success,
                "query": record.action.query,
            })
        if not rows:
            return [{"query_index": None, "query": None}]
        return rows

    def _candidate_language_info(self, state: ProductSearchState, card_or_candidate) -> dict[str, Any]:
        candidate = getattr(card_or_candidate, "candidate", card_or_candidate)
        query_sources = set(getattr(candidate, "query_sources", ()) or ())
        for record in state.actions_taken:
            if record.action.action_type != ActionType.ORGANIC_SEARCH:
                continue
            if record.action.query and record.action.query in query_sources:
                return {
                    "language_code": record.action.metadata.get("language_code"),
                    "language_name": record.action.metadata.get("language_name"),
                    "language_priority": record.action.metadata.get("language_priority"),
                    "language_distribution_weight": record.action.metadata.get("language_distribution_weight"),
                }
        return {}

    def _selected_candidate_language(self, state: ProductSearchState) -> dict[str, Any]:
        final = state.final_result.product_url if state.final_result else None
        if not final:
            return {}
        for card in state.scorecards:
            if card.candidate.url == final:
                return self._candidate_language_info(state, card.candidate)
        return {}

    def _llm_judgement_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        if not state.llm_judgements and not state.llm_call_records:
            return [{"row_id": state.task.row_id, "llm_used": False, "note": "LLM adjudication disabled or no promising candidates"}]
        rows: list[dict[str, Any]] = []
        for url, j in state.llm_judgements.items():
            rows.append({
                "row_id": state.task.row_id,
                "url": url,
                "llm_call_index": j.call_index,
                "payload_level": j.payload_level,
                "image_used": j.image_used,
                "image_url": j.image_url,
                "gateway_retry": j.gateway_retry,
                "decision": j.decision,
                "exact_product_match": j.exact_product_match,
                "confidence": j.confidence,
                "primary_identity_driver": j.primary_identity_driver,
                "main_text_status": j.main_text_status,
                "ean_status": j.ean_status,
                "variant_status": j.variant_status,
                "scrape_usable": j.scrape_usable,
                "image_status": j.image_status,
                "reject_reason": j.reject_reason,
                "final_explanation": j.final_explanation,
                "error": j.error,
            })
        return rows or [{"row_id": state.task.row_id, "llm_used": False}]

    def _llm_call_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        return [r.to_dict() for r in state.llm_call_records]


    def _identity_graph_row(self, state: ProductSearchState) -> dict[str, Any]:
        graph = state.identity_graph
        if hasattr(graph, "to_dict"):
            data = graph.to_dict()
        else:
            data = {}
        return {
            "row_id": state.task.row_id,
            "raw_main_text": data.get("raw_main_text", state.task.main_text),
            "normalized_main_text": data.get("normalized_main_text"),
            "expanded_product_name_candidates": "|".join(data.get("expanded_product_name_candidates", []) or []),
            "must_match_terms": "|".join(data.get("must_match_terms", []) or []),
            "variant_terms": "|".join(data.get("variant_terms", []) or []),
            "size_terms": "|".join(data.get("size_terms", []) or []),
            "color_terms": "|".join(data.get("color_terms", []) or []),
            "quantity_terms": "|".join(data.get("quantity_terms", []) or []),
            "product_form_terms": "|".join(data.get("product_form_terms", []) or []),
            "product_form_families": "|".join(data.get("product_form_families", []) or []),
            "input_ean": data.get("input_ean"),
            "input_validation_status": "WARN" if state.task.input_validation_warnings else "OK",
            "input_validation_warnings": "|".join(state.task.input_validation_warnings),
            "country_code": data.get("country_code", state.task.country_code),
        }

    def _detector_finding_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for url, findings in state.detector_findings.items():
            for idx, finding in enumerate(findings, start=1):
                rows.append({
                    "row_id": state.task.row_id,
                    "url": url,
                    "finding_index": idx,
                    "detector": finding.get("detector"),
                    "status": finding.get("status"),
                    "severity": finding.get("severity"),
                    "input_value": finding.get("input_value"),
                    "page_value": finding.get("page_value"),
                    "explanation": finding.get("explanation"),
                })
        return rows

    def _evidence_scorecard_rows(self, state: ProductSearchState) -> list[dict[str, Any]]:
        rows = []
        for rank, card in enumerate(state.scorecards, start=1):
            s = card.scrape
            v = card.verification
            rows.append({
                "row_id": state.task.row_id,
                "rank": rank,
                "url": card.candidate.url,
                "organic_score": card.organic_score,
                "ai_score": card.ai_score,
                "retailer_score": card.retailer_score,
                "country_score": card.country_score,
                "ean_score": card.ean_score,
                "title_score": card.title_score,
                "product_page_score": card.product_page_score,
                "scrape_score": card.scrape_score,
                "identity_score": card.identity_score,
                "richness_score": card.richness_score,
                "weighted_confidence": card.weighted_confidence,
                "confidence_cap": card.confidence_cap,
                "final_confidence": card.final_confidence,
                "validation_status": card.validation_status,
                "identity_status": v.identity_status if v else "UNVERIFIED",
                "exact_product_check": v.exact_product_check if v else "UNKNOWN",
                "variant_check": v.variant_check if v else "UNKNOWN",
                "scrapable": bool(s and s.is_scrapable),
                "product_page": bool(s and s.looks_like_product_page),
                "word_count": s.word_count if s else 0,
                "specs_count": len(s.specs) if s else 0,
                "image_count": s.image_count if s else 0,
                "hard_failures": "; ".join(card.hard_failures),
                "soft_warnings": "; ".join(card.soft_warnings),
            })
        return rows

    def _run_summary(self, state: ProductSearchState) -> dict[str, Any]:
        final = state.final_result
        return {
            "row_id": state.task.row_id,
            "main_text": state.task.main_text,
            "country_code": state.task.country_code,
            "product_url": final.product_url if final else None,
            "verified_exact_url": final.verified_exact_url if final else None,
            "best_available_url": final.best_available_url if final else None,
            "best_reference_url": final.best_reference_url if final else None,
            "url_decision_status": final.url_decision_status if final else "UNRESOLVED",
            "input_validation_warnings": list(state.task.input_validation_warnings),
            "needs_review": final.needs_review if final else True,
            "candidate_count": len(state.candidates),
            "scrape_count": len(state.scrapes),
            "llm_calls_used": len(state.llm_call_records),
            "loop_iterations": state.iteration,
            "search_iterations": sum(1 for a in state.actions_taken if a.action.action_type == ActionType.ORGANIC_SEARCH),
            "scrape_iterations": sum(1 for a in state.actions_taken if a.action.action_type == ActionType.SCRAPE_URL),
            "judge_iterations": sum(1 for a in state.actions_taken if a.action.action_type == ActionType.LLM_EXACT_ADJUDICATION),
            "repair_cycles": sum(1 for p in state.llm_search_plans if p.stage == "search_feedback"),
            "country_search_iterations": sum(1 for a in state.actions_taken if a.action.action_type == ActionType.ORGANIC_SEARCH and a.action.metadata.get("scope") != "global"),
            "global_search_iterations": sum(1 for a in state.actions_taken if a.action.action_type == ActionType.ORGANIC_SEARCH and a.action.metadata.get("scope") == "global"),
            "detector_finding_count": sum(len(x) for x in state.detector_findings.values()),
            "hard_conflict_count": sum(1 for findings in state.detector_findings.values() for f in findings if f.get("status") == "CONFLICT" and f.get("severity") == "HARD_BLOCKER"),
            "termination_reason": state.termination_reason,
        }

    def _write_csv(self, path: Path, rows: Iterable[dict[str, Any]]) -> None:
        rows = list(rows)
        if not rows:
            path.write_text("", encoding="utf-8")
            return
        fieldnames: list[str] = []
        for row in rows:
            for key in row.keys():
                if key not in fieldnames:
                    fieldnames.append(key)
        with path.open("w", encoding="utf-8", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=fieldnames)
            writer.writeheader()
            writer.writerows(rows)

    def _write_json(self, path: Path, obj: Any) -> None:
        path.write_text(json.dumps(obj, ensure_ascii=False, indent=2, default=str), encoding="utf-8")

    def _safe(self, value: str) -> str:
        return "".join(ch if ch.isalnum() or ch in {"-", "_"} else "_" for ch in value)[:120]
