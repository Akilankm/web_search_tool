"""Batch runner for the Exact Product Discovery Harness.

Usage:
  python batch_main.py --input data/products.xlsx --output outputs/product_url_matches.csv --workers 4

The runner reads all columns as strings to protect EAN/GTIN identifiers.
It creates one harness per worker call to avoid shared crawl/browser/session state.
"""

from __future__ import annotations

import argparse
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

import pandas as pd  # noqa: E402
from rich import print  # noqa: E402
from tqdm.auto import tqdm  # noqa: E402

from product_evidence_harness import (  # noqa: E402
    CSVProductIO,
    HarnessConfig,
    ProductEvidenceHarness,
    SerpAPIConfig,
    configure_logging,
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Run exact-product URL discovery for a batch file.")
    parser.add_argument("--input", required=True, help="CSV/XLSX with row_id, main_text, country_code, optional ean, retailer_name")
    parser.add_argument("--output", default="outputs/product_url_matches.csv")
    parser.add_argument("--workers", type=int, default=2)
    parser.add_argument("--env-file", default=".env")
    parser.add_argument("--log-level", default="INFO")
    return parser.parse_args()


def build_harness(product, env_file: str) -> ProductEvidenceHarness:
    serp_config = SerpAPIConfig.from_env(
        country_code=product.country_code,
        language_code=product.language_code or "en",
        env_file=env_file,
        no_cache=False,
    )
    return ProductEvidenceHarness(serp_config=serp_config, config=HarnessConfig.from_env(env_file))


def process(product, env_file: str):
    try:
        harness = build_harness(product, env_file)
        match = harness.run(product)
        return match.to_dict() | {"status": "success", "error": None}
    except Exception as exc:
        return {
            "row_id": product.row_id,
            "main_text": product.main_text,
            "country_code": product.country_code,
            "retailer_name": product.retailer_name,
            "ean": product.ean,
            "product_url": None,
            "best_available_url": None,
            "verified_exact_url": None,
            "best_reference_url": None,
            "confidence": 0.0,
            "validation_status": "ERROR",
            "identity_status": "ERROR",
            "status": "error",
            "error": str(exc),
        }


def main() -> None:
    args = parse_args()
    configure_logging(args.log_level)
    products = CSVProductIO.read_products(Path(args.input))
    print(f"[bold cyan]Loaded {len(products)} products[/bold cyan]")
    rows = []
    with ThreadPoolExecutor(max_workers=max(1, args.workers)) as executor:
        futures = [executor.submit(process, p, args.env_file) for p in products]
        for future in tqdm(as_completed(futures), total=len(futures), desc="Processing"):
            rows.append(future.result())
    out = Path(args.output)
    out.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(out, index=False)
    print(f"[bold green]Wrote {out}[/bold green]")


if __name__ == "__main__":
    main()
