"""Single-product local demo for Product Evidence Harness."""

from __future__ import annotations

import sys
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent
SRC_PATH = PROJECT_ROOT / "src"
if str(SRC_PATH) not in sys.path:
    sys.path.insert(0, str(SRC_PATH))

from product_evidence_harness import (  # noqa: E402
    DiscoveryMode,
    HarnessBudgetConfig,
    HarnessConfig,
    HarnessPolicy,
    ProductEvidenceHarness,
    ProductQuery,
    RichPrinter,
    SerpAPIConfig,
    configure_logging,
)

configure_logging("INFO")
printer = RichPrinter()

# Country/language defaults can come from country_profiles.json. SerpAPIConfig
# still needs a default gl/hl for API calls; ProductQuery can override both.
serp_config = SerpAPIConfig.from_env(country_code="CH", language_code="de", no_cache=False)
config = HarnessConfig(
    budget=HarnessBudgetConfig(
        max_organic_searches=3,  # country primary + country secondary + global fallback if needed
        max_ai_mode_searches=2,
        max_scrapes=6,
        max_iterations=10,
    ),
    policy=HarnessPolicy(
        discovery_mode=DiscoveryMode.PRODUCT_EVIDENCE,
        require_scrapable_primary=True,
        allow_global_fallback=True,
        require_country_specific_before_global=True,
        allow_ai_only_reference=False,
        allow_pack_size_mismatch=False,
        allow_ean_conflict=False,
    ),
    write_outputs=True,
    output_dir="./output",
    # Optional: override editable country/language profile.
    # country_profile_path="./configs/my_country_profiles.json",
)

harness = ProductEvidenceHarness(serp_config=serp_config, config=config)

product = ProductQuery(
    row_id="demo-001",
    main_text="LEGO City Feuerwehrstation",
    country_code="CH",
    retailer_name=None,
    ean="5702011234567",
    language_code=None,  # inferred from CH profile: de, then fr/it/rm/en as needed
)

trace = harness.run(product, return_trace=True)
printer.print_match(trace.best_match)
printer.print_scorecards(trace.scored_candidates)
print("Per-row CSV outputs written under:", config.output_dir)
