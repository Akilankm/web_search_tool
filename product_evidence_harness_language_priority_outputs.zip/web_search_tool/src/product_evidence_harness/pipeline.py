from __future__ import annotations

from dataclasses import dataclass, field, replace
from typing import Optional

from loguru import logger

from product_evidence_harness.artifacts import ArtifactWriter
from product_evidence_harness.budget import BudgetTracker
from product_evidence_harness.candidate_store import CandidateStore
from product_evidence_harness.config import HarnessConfig, SerpAPIConfig
from product_evidence_harness.contracts import HarnessTrace, ProductQuery, ProductSearchState, ProductURLMatch
from product_evidence_harness.country_profiles import CountryProfileRegistry
from product_evidence_harness.evidence_extractor import EvidenceExtractor
from product_evidence_harness.executor import HarnessExecutor
from product_evidence_harness.identity_verifier import ProductIdentityVerifier
from product_evidence_harness.loop import BoundedHarnessLoop
from product_evidence_harness.planner import HarnessPlanner
from product_evidence_harness.query_builder import QueryBuilder
from product_evidence_harness.ranker import ProductURLRanker
from product_evidence_harness.scraper import CrawlScraper
from product_evidence_harness.selector import FinalSelector
from product_evidence_harness.serp_clients import GoogleAIModeClient, GoogleOrganicSearchClient


@dataclass
class ProductEvidenceHarness:
    serp_config: SerpAPIConfig
    config: HarnessConfig = field(default_factory=HarnessConfig)
    organic_client: Optional[GoogleOrganicSearchClient] = None
    ai_client: Optional[GoogleAIModeClient] = None
    scraper: Optional[CrawlScraper] = None
    candidate_store: Optional[CandidateStore] = None
    query_builder: Optional[QueryBuilder] = None
    verifier: Optional[ProductIdentityVerifier] = None
    ranker: Optional[ProductURLRanker] = None
    selector: Optional[FinalSelector] = None
    evidence_extractor: Optional[EvidenceExtractor] = None
    country_profiles: Optional[CountryProfileRegistry] = None

    def __post_init__(self) -> None:
        self.country_profiles = self.country_profiles or CountryProfileRegistry.load(self.config.country_profile_path)
        self.organic_client = self.organic_client or GoogleOrganicSearchClient(self.serp_config)
        self.ai_client = self.ai_client or GoogleAIModeClient(self.serp_config)
        self.scraper = self.scraper or CrawlScraper(
            headless=self.config.crawl_headless,
            verbose=self.config.crawl_verbose,
            page_timeout_ms=self.config.crawl_page_timeout_ms,
            min_word_count=self.config.crawl_min_word_count,
        )
        self.candidate_store = self.candidate_store or CandidateStore(max_pool_size=self.config.max_candidate_pool)
        self.query_builder = self.query_builder or QueryBuilder(country_profiles=self.country_profiles)
        self.verifier = self.verifier or ProductIdentityVerifier(policy=self.config.policy)
        self.ranker = self.ranker or ProductURLRanker(weights=self.config.score_weights, policy=self.config.policy, country_profiles=self.country_profiles)
        self.selector = self.selector or FinalSelector(policy=self.config.policy)
        self.evidence_extractor = self.evidence_extractor or EvidenceExtractor()

    def run(self, product: ProductQuery, *, return_trace: bool = False) -> ProductURLMatch | HarnessTrace:
        if not product.language_code:
            profile = self.country_profiles.get(product.country_code)
            product = replace(product, language_code=profile.default_language)
        logger.info("Starting product evidence harness | row_id={} | country={} | language={} | retailer={}", product.row_id, product.country_code, product.language_code, product.retailer_name)
        budget = BudgetTracker(
            max_organic=self.config.budget.max_organic_searches,
            max_ai_mode=self.config.budget.max_ai_mode_searches,
            max_scrapes=self.config.budget.max_scrapes,
        )
        state = ProductSearchState(task=product, budget=budget)
        executor = HarnessExecutor(
            organic_client=self.organic_client,
            ai_client=self.ai_client,
            scraper=self.scraper,
            candidate_store=self.candidate_store,
            verifier=self.verifier,
            ranker=self.ranker,
            evidence_extractor=self.evidence_extractor,
        )
        planner = HarnessPlanner(config=self.config, query_builder=self.query_builder, country_profiles=self.country_profiles)
        loop = BoundedHarnessLoop(config=self.config, planner=planner, executor=executor)
        state = loop.run(state)
        best_match = self.selector.select(
            task=product,
            scorecards=state.scorecards,
            termination_reason=state.termination_reason,
            budget_snapshot=budget.snapshot(),
        )
        state.final_result = best_match
        if self.config.write_outputs:
            ArtifactWriter(self.config.output_dir, country_profiles=self.country_profiles).write_state(state)
        if self.config.write_artifacts and self.config.artifact_dir:
            ArtifactWriter(self.config.artifact_dir, include_debug_json=True, country_profiles=self.country_profiles).write_state(state)
        logger.info("Completed harness | row_id={} | status={} | identity={} | confidence={} | url={}", product.row_id, best_match.validation_status, best_match.identity_status, best_match.confidence, best_match.product_url)
        trace = HarnessTrace(state=state, best_match=best_match)
        return trace if return_trace else best_match


# Intentional API break from the old linear implementation. The old name is kept
# as an alias only so notebooks fail less noisily while using the new harness.
HarnessProductURLFinderPipeline = ProductEvidenceHarness
HybridProductURLFinderPipeline = ProductEvidenceHarness
