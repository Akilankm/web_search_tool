from __future__ import annotations

import os
from dataclasses import dataclass, field
from typing import Optional

from dotenv import load_dotenv

from product_evidence_harness.constants import DEFAULT_SCORE_WEIGHTS, SERPAPI_API_KEY_ENV, ScoreWeights
from product_evidence_harness.contracts import DiscoveryMode


@dataclass(frozen=True)
class SerpAPIConfig:
    api_key: str
    country_code: str = "us"
    language_code: str = "en"
    device: str = "desktop"
    timeout_seconds: int = 60
    max_retries: int = 3
    backoff_seconds: float = 2.0
    no_cache: bool = False
    location: Optional[str] = None
    organic_num_results: int = 10

    @classmethod
    def from_env(
        cls,
        *,
        country_code: str = "US",
        language_code: str = "en",
        env_file: Optional[str] = ".env",
        **overrides,
    ) -> "SerpAPIConfig":
        if env_file:
            load_dotenv(env_file)
        else:
            load_dotenv()
        api_key = os.getenv(SERPAPI_API_KEY_ENV)
        if not api_key:
            raise ValueError(f"{SERPAPI_API_KEY_ENV} not found in environment")
        return cls(
            api_key=api_key,
            country_code=country_code.lower(),
            language_code=language_code.lower(),
            **overrides,
        )


@dataclass(frozen=True)
class HarnessPolicy:
    discovery_mode: DiscoveryMode = DiscoveryMode.PRODUCT_EVIDENCE
    require_scrapable_primary: bool = True
    allow_global_fallback: bool = True
    allow_ai_only_reference: bool = False
    allow_pack_size_mismatch: bool = False
    allow_ean_conflict: bool = False
    min_verified_confidence: float = 0.80
    min_review_confidence: float = 0.30
    min_title_overlap: float = 0.35
    high_confidence_requires_hard_evidence: bool = True
    require_country_specific_before_global: bool = True


@dataclass(frozen=True)
class HarnessBudgetConfig:
    # Default supports: country primary search, country secondary/repair search,
    # and a final global fallback search when no country-specific candidate exists.
    max_organic_searches: int = 4
    max_ai_mode_searches: int = 2
    max_scrapes: int = 10
    max_iterations: int = 14


@dataclass(frozen=True)
class HarnessConfig:
    budget: HarnessBudgetConfig = field(default_factory=HarnessBudgetConfig)
    policy: HarnessPolicy = field(default_factory=HarnessPolicy)
    score_weights: ScoreWeights = DEFAULT_SCORE_WEIGHTS
    max_candidates_for_ai: int = 12
    max_candidate_pool: int = 40
    scrape_enabled: bool = True
    crawl_headless: bool = True
    crawl_verbose: bool = False
    crawl_page_timeout_ms: int = 45000
    crawl_min_word_count: int = 20
    write_outputs: bool = True
    output_dir: str = "output"
    # Legacy/debug artifact switch. Keep disabled by default to avoid dumping large JSON/markdown.
    write_artifacts: bool = False
    artifact_dir: Optional[str] = None
    country_profile_path: Optional[str] = None


# Backwards-compatible name, but the semantics are now harness-level.
PipelineConfig = HarnessConfig
