from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from product_evidence_harness.contracts import ProductQuery, ProductSearchState, URLCandidate
from product_evidence_harness.country_profiles import CountryProfileRegistry, LanguageProfile


@dataclass(frozen=True)
class QueryBuilder:
    """Builds bounded, auditable search queries.

    Country code controls TLD/geography and ordered language-market search.
    Retailer domains are not maintained in configuration; retailer_name, when
    supplied, is used only as a dynamic text signal in the query and scoring.
    """

    max_query_chars: int = 520
    country_profiles: CountryProfileRegistry = field(default_factory=CountryProfileRegistry.load)

    def country_language_count(self, task: ProductQuery) -> int:
        return len(self.country_profiles.language_profiles_for(task.country_code, task.language_code))

    def country_language_metadata(self, task: ProductQuery, language_index: int) -> dict[str, Any]:
        profile = self.country_profiles.get(task.country_code)
        languages = profile.language_profiles_for(task.language_code)
        idx = max(0, min(language_index, len(languages) - 1))
        lp = languages[idx]
        return {
            "scope": "country",
            "kind": "country_language",
            "country_code": task.country_code,
            "country_name": profile.country_name,
            "language_index": idx,
            "language_code": lp.language_code,
            "language_name": lp.language_name,
            "language_priority": lp.priority,
            "language_distribution_weight": lp.distribution_weight,
        }

    def country_language_search(self, task: ProductQuery, *, language_index: int = 0, repair: bool = False, state: ProductSearchState | None = None) -> str:
        profile = self.country_profiles.get(task.country_code)
        languages = profile.language_profiles_for(task.language_code)
        idx = max(0, min(language_index, len(languages) - 1))
        lp = languages[idx]

        parts: list[str] = []
        if task.ean:
            parts.append(task.ean)

        if repair and state:
            parts.extend(self._repair_clues(state))
        elif idx == 0:
            parts.append(self._quote(task.main_text))
        else:
            # Recall searches in non-primary languages use distinctive tokens so
            # translated/localized retailer pages are not blocked by an exact
            # main_text phrase in another language.
            parts.extend(self._distinctive_tokens(task.main_text, max_tokens=8))

        if task.retailer_name:
            parts.append(task.retailer_name)

        parts.extend(self._country_filter_terms(task))
        parts.extend(self._language_country_terms(lp, profile_country_name=profile.country_name, max_terms=3))
        parts.extend(self._localized_terms(lp, max_terms=4))
        return self._truncate(" ".join(parts))

    def primary(self, task: ProductQuery, *, global_fallback: bool = False) -> str:
        if not global_fallback:
            return self.country_language_search(task, language_index=0)
        return self.global_fallback(task)

    def secondary(self, task: ProductQuery, *, global_fallback: bool = False) -> str:
        if not global_fallback:
            return self.country_language_search(task, language_index=1)
        return self.global_fallback(task)

    def global_fallback(self, task: ProductQuery) -> str:
        parts: list[str] = []
        if task.ean:
            parts.append(task.ean)
        parts.append(self._quote(task.main_text))
        if task.retailer_name:
            parts.append(task.retailer_name)
        parts.append("retailer product page")
        parts.extend(["buy", "shop", "price"])
        return self._truncate(" ".join(parts))

    def repair_from_state(self, state: ProductSearchState, *, global_fallback: bool = False) -> str:
        if global_fallback:
            task = state.task
            parts = []
            if task.ean:
                parts.append(task.ean)
            parts.extend(self._repair_clues(state) or self._distinctive_tokens(task.main_text, max_tokens=7))
            if task.retailer_name:
                parts.append(task.retailer_name)
            parts.extend(["product page", "buy", "shop"])
            return self._truncate(" ".join(parts))

        # Keep country repair in the highest-priority language by default. The
        # planner only reaches repair after language-priority searches have run.
        return self.country_language_search(state.task, language_index=0, repair=True, state=state)

    def ai_discovery_prompt(self, task: ProductQuery, *, allow_global_fallback: bool = True) -> str:
        profile = self.country_profiles.get(task.country_code)
        language_lines = self._language_profile_lines(task)
        country_terms = ", ".join(self.country_profiles.country_context_terms(task.country_code, task.language_code)) or "not_configured"
        return self._truncate("\n".join([
            "Find ecommerce product detail page URLs for a product evidence harness.",
            "Return only URLs that are likely product detail pages. Prefer requested-country URLs first.",
            "Do not return category/search/home/social/PDF/image URLs.",
            "Use FINAL_URL: <url> for the best candidate, or FINAL_URL: NO_MATCH if no plausible URL exists.",
            "Also list up to 5 alternate candidate URLs under REFERENCES.",
            "Retailers are not preconfigured. Discover retailer pages dynamically from the web.",
            "",
            "PRODUCT:",
            f"main_text: {task.main_text}",
            f"country_code: {task.country_code}",
            f"country_name: {profile.country_name}",
            f"country_tlds: {', '.join(profile.tlds) or 'not_configured'}",
            "country_language_priority:",
            *language_lines,
            f"country_terms: {country_terms}",
            f"retailer_name: {task.retailer_name or 'not_provided'}",
            f"ean_gtin: {task.ean or 'not_provided'}",
            f"global_fallback_allowed: {str(allow_global_fallback)}",
        ]))

    def ai_validation_prompt(self, task: ProductQuery, candidates: list[URLCandidate], *, allow_global_fallback: bool = True) -> str:
        profile = self.country_profiles.get(task.country_code)
        language_lines = self._language_profile_lines(task)
        country_terms = ", ".join(self.country_profiles.country_context_terms(task.country_code, task.language_code)) or "not_configured"
        lines = [
            "You are validating ecommerce product URL candidates for a product evidence harness.",
            "Decision policy:",
            "1. Prefer exact product detail pages from the requested country.",
            "2. Treat EAN/GTIN as the strongest identity signal. If provided, a matching EAN beats title-only evidence.",
            "3. Retailers are not preconfigured. Use the URL/page evidence, not a static retailer list.",
            "4. If no requested-country product page is available, a global fallback URL is allowed but must be marked as fallback evidence.",
            "5. Reject category/search/home/social/PDF/image pages as final product URLs.",
            "6. Final URL must still be scraped and verified by the harness; you are only providing candidate evidence.",
            "Return concise evidence only.",
            "Use FINAL_URL: <url> if one candidate is the best match, else FINAL_URL: NO_MATCH.",
            "Also state EAN_EVIDENCE, TITLE_EVIDENCE, RETAILER_EVIDENCE, COUNTRY_EVIDENCE, PRODUCT_PAGE_EVIDENCE, FALLBACK_REASON.",
            "",
            "PRODUCT:",
            f"main_text: {task.main_text}",
            f"country_code: {task.country_code}",
            f"country_name: {profile.country_name}",
            f"country_tlds: {', '.join(profile.tlds) or 'not_configured'}",
            "country_language_priority:",
            *language_lines,
            f"country_terms: {country_terms}",
            f"retailer_name: {task.retailer_name or 'not_provided'}",
            f"ean_gtin: {task.ean or 'not_provided'}",
            f"global_fallback_allowed: {str(allow_global_fallback)}",
            "",
            "CANDIDATES:",
        ]
        for idx, c in enumerate(candidates[:12], start=1):
            country_specific = self.country_profiles.domain_matches_country(c.url, task.country_code)
            lines.extend([
                f"{idx}. url: {c.url}",
                f"   country_specific_domain: {country_specific}",
                f"   title: {c.title[:180]}",
                f"   snippet: {c.snippet[:240]}",
                f"   source_types: {', '.join(c.source_types)}",
            ])
        return self._truncate("\n".join(lines))

    def _language_profile_lines(self, task: ProductQuery) -> list[str]:
        lines = []
        for lp in self.country_profiles.language_profiles_for(task.country_code, task.language_code):
            lines.append(
                f"- {lp.language_code} ({lp.language_name}): priority={lp.priority}, distribution_weight={lp.distribution_weight}"
            )
        return lines

    def _country_filter_terms(self, task: ProductQuery, *, max_domain_hints: int = 4) -> list[str]:
        hints = list(self.country_profiles.country_hints(task.country_code, max_domain_hints=max_domain_hints))
        if not hints:
            return []
        if len(hints) == 1:
            return hints
        return ["(" + " OR ".join(hints[:max_domain_hints]) + ")"]

    def _language_country_terms(self, lp: LanguageProfile, *, profile_country_name: str, max_terms: int) -> list[str]:
        terms = list(lp.country_terms)
        if profile_country_name:
            terms.append(profile_country_name)
        terms = list(dict.fromkeys(t for t in terms if t))[:max_terms]
        if not terms:
            return []
        return ["(" + " OR ".join(terms) + ")"] if len(terms) > 1 else terms

    def _localized_terms(self, lp: LanguageProfile, *, max_terms: int) -> list[str]:
        terms = list(dict.fromkeys(t for t in lp.commerce_terms if t))[:max_terms]
        if not terms:
            return ["buy"]
        return ["(" + " OR ".join(terms) + ")"] if len(terms) > 1 else terms

    def _repair_clues(self, state: ProductSearchState) -> list[str]:
        best = state.best_scorecard()
        clues: list[str] = []
        if best and best.scrape:
            s = best.scrape
            for value in [s.page_product_name, s.brand, s.manufacturer, s.h1, s.title]:
                if value:
                    clues.extend(self._distinctive_tokens(value, max_tokens=4))
        if not clues:
            clues = self._distinctive_tokens(state.task.main_text, max_tokens=7)
        out: list[str] = []
        seen: set[str] = set()
        if state.task.ean:
            out.append(state.task.ean)
            seen.add(state.task.ean.lower())
        for token in clues:
            key = token.lower()
            if key not in seen:
                seen.add(key)
                out.append(token)
            if len(out) >= 10:
                break
        return out

    def _quote(self, text: str) -> str:
        return f'"{text.strip().replace(chr(34), "")}"'

    def _distinctive_tokens(self, text: str, *, max_tokens: int) -> list[str]:
        stop = {"with", "from", "and", "the", "toy", "toys", "figure", "figurka", "set", "pack", "pcs", "ks"}
        tokens = [t for t in re.findall(r"[a-zA-Z0-9À-ž]+", text or "") if len(t) >= 3 and t.lower() not in stop]
        model = [t for t in tokens if re.search(r"[A-Za-z]", t) and re.search(r"\d", t)]
        rest = [t for t in tokens if t not in model]
        seen: set[str] = set()
        out: list[str] = []
        for token in model + rest:
            key = token.lower()
            if key not in seen:
                seen.add(key)
                out.append(token)
            if len(out) >= max_tokens:
                break
        return out

    def _truncate(self, query: str) -> str:
        query = " ".join(str(query).split())
        if len(query) <= self.max_query_chars:
            return query
        return query[: self.max_query_chars].rsplit(" ", 1)[0]
